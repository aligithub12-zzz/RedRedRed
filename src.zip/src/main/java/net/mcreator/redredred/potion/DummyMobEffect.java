package net.mcreator.redredred.potion;

import net.neoforged.neoforge.common.NeoForgeMod;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.redredred.RedredredMod;

public class DummyMobEffect extends MobEffect {
	public DummyMobEffect() {
		super(MobEffectCategory.HARMFUL, -3355444);
		this.addAttributeModifier(Attributes.MOVEMENT_SPEED, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.dummy_0"), 0.2, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.ARMOR, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.dummy_1"), -20, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.SCALE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.dummy_2"), 2, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(NeoForgeMod.SWIM_SPEED, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.dummy_3"), -10, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.MAX_HEALTH, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.dummy_4"), -19, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.BLOCK_INTERACTION_RANGE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.dummy_5"), 1000, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.ATTACK_DAMAGE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.dummy_6"), -999, AttributeModifier.Operation.ADD_VALUE);
	}
}