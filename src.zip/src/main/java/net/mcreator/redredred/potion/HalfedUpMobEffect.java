package net.mcreator.redredred.potion;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.redredred.init.RedredredModAttributes;
import net.mcreator.redredred.RedredredMod;

public class HalfedUpMobEffect extends MobEffect {
	public HalfedUpMobEffect() {
		super(MobEffectCategory.HARMFUL, -10066177);
		this.addAttributeModifier(Attributes.MAX_HEALTH, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.halfed_up_0"), -10, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.ARMOR, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.halfed_up_1"), -0.5, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.MOVEMENT_SPEED, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.halfed_up_2"), -0.5, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.SCALE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.halfed_up_3"), -0.5, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.BLOCK_INTERACTION_RANGE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.halfed_up_4"), -0.5, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.STEP_HEIGHT, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.halfed_up_5"), -0.5, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.FALL_DAMAGE_MULTIPLIER, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.halfed_up_6"), -0.5, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.ATTACK_DAMAGE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.halfed_up_7"), -0.5, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(Attributes.ATTACK_KNOCKBACK, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.halfed_up_8"), -0.5, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		this.addAttributeModifier(RedredredModAttributes.LOSER_SCORE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.halfed_up_9"), 1, AttributeModifier.Operation.ADD_VALUE);
	}
}