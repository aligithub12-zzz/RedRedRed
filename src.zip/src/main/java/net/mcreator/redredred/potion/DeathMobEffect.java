package net.mcreator.redredred.potion;

import net.neoforged.neoforge.event.ModifyDefaultComponentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.consume_effects.RemoveStatusEffectsConsumeEffect;
import net.minecraft.world.item.consume_effects.ConsumeEffect;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.item.Items;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.component.DataComponents;

import net.mcreator.redredred.init.RedredredModParticleTypes;
import net.mcreator.redredred.init.RedredredModMobEffects;
import net.mcreator.redredred.RedredredMod;

import java.util.List;
import java.util.ArrayList;

@EventBusSubscriber
public class DeathMobEffect extends MobEffect {
	public DeathMobEffect() {
		super(MobEffectCategory.HARMFUL, -65281, mobEffectInstance -> (SimpleParticleType) (RedredredModParticleTypes.PINK_UNKNOWNESS.get()));
		this.addAttributeModifier(Attributes.MAX_HEALTH, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.death_0"), -18, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.ARMOR, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.death_1"), -4, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.STEP_HEIGHT, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.death_2"), 20, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.SNEAKING_SPEED, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.death_3"), -3, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.ATTACK_KNOCKBACK, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.death_4"), -8, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.CAMERA_DISTANCE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.death_5"), -8, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.FALL_DAMAGE_MULTIPLIER, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.death_6"), 20, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.WATER_MOVEMENT_EFFICIENCY, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.death_7"), -1, AttributeModifier.Operation.ADD_VALUE);
	}

	@SubscribeEvent
	public static void modifyItemComponents(ModifyDefaultComponentsEvent event) {
		Consumable original = Items.HONEY_BOTTLE.components().get(DataComponents.CONSUMABLE);
		if (original != null) {
			List<ConsumeEffect> onConsumeEffects = new ArrayList<>(original.onConsumeEffects());
			onConsumeEffects.add(new RemoveStatusEffectsConsumeEffect(RedredredModMobEffects.DEATH));
			Consumable replacementConsumable = new Consumable(original.consumeSeconds(), original.animation(), original.sound(), original.hasConsumeParticles(), onConsumeEffects);
			event.modify(Items.HONEY_BOTTLE, builder -> builder.set(DataComponents.CONSUMABLE, replacementConsumable));
		}
	}
}