package net.mcreator.redredred.potion;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.redredred.init.RedredredModParticleTypes;
import net.mcreator.redredred.init.RedredredModAttributes;
import net.mcreator.redredred.RedredredMod;

public class WaitWhatMobEffect extends MobEffect {
	public WaitWhatMobEffect() {
		super(MobEffectCategory.HARMFUL, -10066177, mobEffectInstance -> (SimpleParticleType) (RedredredModParticleTypes.HUH_PARTICLE.get()));
		this.addAttributeModifier(RedredredModAttributes.LOSER_SCORE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_0"), 1, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.ATTACK_DAMAGE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_1"), -999, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.GRAVITY, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_2"), 0, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.LUCK, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_3"), -937, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.WATER_MOVEMENT_EFFICIENCY, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_4"), -1, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.FALL_DAMAGE_MULTIPLIER, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_5"), 100, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.JUMP_STRENGTH, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_6"), 3, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.SCALE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_7"), 3, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.ATTACK_KNOCKBACK, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_8"), 60, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.EXPLOSION_KNOCKBACK_RESISTANCE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_9"), -10, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.MAX_HEALTH, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_10"), -19, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.STEP_HEIGHT, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_11"), 100, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.SNEAKING_SPEED, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_12"), -100, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.OXYGEN_BONUS, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "effect.wait_what_13"), -19, AttributeModifier.Operation.ADD_VALUE);
	}
}