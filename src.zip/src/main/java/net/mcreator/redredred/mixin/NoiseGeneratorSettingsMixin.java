package net.mcreator.redredred.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.redredred.init.RedredredModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements RedredredModBiomes.RedredredModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> redredred_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.redredred_dimensionTypeReference != null) {
			retval = RedredredModBiomes.adaptSurfaceRule(retval, this.redredred_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setredredredDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.redredred_dimensionTypeReference = dimensionType;
	}
}