package net.mcreator.redredred.item;

import net.minecraft.world.item.Item;

public class RedgemItem extends Item {
	public RedgemItem(Item.Properties properties) {
		super(properties);
	}
}