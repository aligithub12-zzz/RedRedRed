package net.mcreator.redredred.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class YelgemItem extends Item {
	public YelgemItem(Item.Properties properties) {
		super(properties);
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}