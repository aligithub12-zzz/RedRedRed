package net.mcreator.redredred.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.redredred.init.RedredredModFluids;

public class IHateYouItem extends BucketItem {
	public IHateYouItem(Item.Properties properties) {
		super(RedredredModFluids.I_HATE_YOU.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}