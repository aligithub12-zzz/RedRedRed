package net.mcreator.redredred.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class RedgemAxeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 323, 7f, 0, 17, TagKey.create(Registries.ITEM, ResourceLocation.parse("redredred:redgem_axe_repair_items")));

	public RedgemAxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 10f, -3f, properties);
	}
}