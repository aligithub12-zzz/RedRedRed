package net.mcreator.redredred.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class RepeatingCommandShovelItem extends ShovelItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 6280, 48f, 0, 280, TagKey.create(Registries.ITEM, ResourceLocation.parse("redredred:repeating_command_shovel_repair_items")));

	public RepeatingCommandShovelItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 89f, 16f, properties);
	}
}