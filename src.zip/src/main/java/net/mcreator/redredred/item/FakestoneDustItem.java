package net.mcreator.redredred.item;

import net.minecraft.world.item.Item;

public class FakestoneDustItem extends Item {
	public FakestoneDustItem(Item.Properties properties) {
		super(properties);
	}
}