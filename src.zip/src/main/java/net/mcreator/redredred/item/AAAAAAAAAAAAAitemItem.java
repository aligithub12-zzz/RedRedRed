package net.mcreator.redredred.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BannerPattern;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.component.DataComponents;

import net.mcreator.redredred.RedredredMod;

public class AAAAAAAAAAAAAitemItem extends Item {
	public static final TagKey<BannerPattern> PROVIDED_PATTERNS = TagKey.create(Registries.BANNER_PATTERN, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "pattern_item/aaaaaaaaaaaa_aitem"));

	public AAAAAAAAAAAAAitemItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC).component(DataComponents.PROVIDES_BANNER_PATTERNS, PROVIDED_PATTERNS).attributes(ItemAttributeModifiers.builder()
				.add(Attributes.STEP_HEIGHT, new AttributeModifier(ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "aaaaaaaaaaaa_aitem_0"), -0.4, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY).build()));
	}

	@Override
	public float getDestroySpeed(ItemStack itemstack, BlockState state) {
		return 10f;
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}

	@Override
	public boolean isCorrectToolForDrops(ItemStack itemstack, BlockState state) {
		return true;
	}
}