package net.mcreator.redredred.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.redredred.init.RedredredModFluids;

public class MoltenDiamondItem extends BucketItem {
	public MoltenDiamondItem(Item.Properties properties) {
		super(RedredredModFluids.MOLTEN_DIAMOND.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}