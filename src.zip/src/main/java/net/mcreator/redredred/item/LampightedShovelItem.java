package net.mcreator.redredred.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class LampightedShovelItem extends ShovelItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1037, 11f, 0, 39, TagKey.create(Registries.ITEM, ResourceLocation.parse("redredred:lampighted_shovel_repair_items")));

	public LampightedShovelItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 11f, -1f, properties);
	}
}