package net.mcreator.redredred.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class RepeatingCommandAxeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 12416, 512f, 0, 240, TagKey.create(Registries.ITEM, ResourceLocation.parse("redredred:repeating_command_axe_repair_items")));

	public RepeatingCommandAxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 899f, 5f, properties.fireResistant());
	}
}