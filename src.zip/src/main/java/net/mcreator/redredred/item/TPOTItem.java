package net.mcreator.redredred.item;

import net.neoforged.neoforge.common.NeoForgeMod;

import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.redredred.RedredredMod;

public class TPOTItem extends Item {
	public TPOTItem(Item.Properties properties) {
		super(properties.durability(32).repairable(TagKey.create(Registries.ITEM, ResourceLocation.parse("redredred:tpot_repair_items")))
				.attributes(
						ItemAttributeModifiers.builder().add(NeoForgeMod.SWIM_SPEED, new AttributeModifier(ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "tpot_0"), 0.012, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.OFFHAND)
								.add(Attributes.ATTACK_KNOCKBACK, new AttributeModifier(ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "tpot_1"), 99, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.OFFHAND).build())
				.jukeboxPlayable(ResourceKey.create(Registries.JUKEBOX_SONG, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "tpot"))));
	}
}