package net.mcreator.redredred.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.redredred.init.RedredredModFluids;

public class NotHereItem extends BucketItem {
	public NotHereItem(Item.Properties properties) {
		super(RedredredModFluids.NOT_HERE.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}