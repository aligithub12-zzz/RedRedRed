package net.mcreator.redredred.item;

import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.redredred.RedredredMod;

public class SeverelyCrackedTPOTMusicDiscItem extends Item {
	public SeverelyCrackedTPOTMusicDiscItem(Item.Properties properties) {
		super(properties
				.attributes(ItemAttributeModifiers.builder()
						.add(Attributes.MOVEMENT_SPEED, new AttributeModifier(ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "severely_cracked_tpot_music_disc_0"), -0.035, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY)
						.add(Attributes.GRAVITY, new AttributeModifier(ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "severely_cracked_tpot_music_disc_1"), 0.02, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY).build())
				.jukeboxPlayable(ResourceKey.create(Registries.JUKEBOX_SONG, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "severely_cracked_tpot_music_disc"))));
	}
}