package net.mcreator.redredred.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.redredred.init.RedredredModFluids;

public class ClufidItem extends BucketItem {
	public ClufidItem(Item.Properties properties) {
		super(RedredredModFluids.CLUFID.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}