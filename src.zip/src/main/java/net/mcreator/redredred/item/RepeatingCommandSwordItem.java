package net.mcreator.redredred.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class RepeatingCommandSwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 128000, 120000f, 0, 680, TagKey.create(Registries.ITEM, ResourceLocation.parse("redredred:repeating_command_sword_repair_items")));

	public RepeatingCommandSwordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 119999f, 96f));
	}
}