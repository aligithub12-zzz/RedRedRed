package net.mcreator.redredred.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class LampightedAxeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1037, 11f, 0, 39, TagKey.create(Registries.ITEM, ResourceLocation.parse("redredred:lampighted_axe_repair_items")));

	public LampightedAxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 24f, -2f, properties);
	}
}