package net.mcreator.redredred.item;

import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.redredred.RedredredMod;

public class Instamine3000Item extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_IRON_TOOL, 7604, 255f, 0, 74, TagKey.create(Registries.ITEM, ResourceLocation.parse("redredred:instamine_3000_repair_items")));

	public Instamine3000Item(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 3f, -3f)
				.attributes(ItemAttributeModifiers.builder().add(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_ID, 3, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
						.add(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_ID, -3, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
						.add(Attributes.LUCK, new AttributeModifier(ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "instamine_3000_0"), 14, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY)
						.add(Attributes.MINING_EFFICIENCY, new AttributeModifier(ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "instamine_3000_1"), 999, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY)
						.add(Attributes.BLOCK_BREAK_SPEED, new AttributeModifier(ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, "instamine_3000_2"), 999, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY).build()));
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}