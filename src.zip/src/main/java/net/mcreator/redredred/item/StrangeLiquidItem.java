package net.mcreator.redredred.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.redredred.init.RedredredModFluids;

public class StrangeLiquidItem extends BucketItem {
	public StrangeLiquidItem(Item.Properties properties) {
		super(RedredredModFluids.STRANGE_LIQUID.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}