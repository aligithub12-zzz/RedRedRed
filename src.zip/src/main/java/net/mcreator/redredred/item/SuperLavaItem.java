package net.mcreator.redredred.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.redredred.init.RedredredModFluids;

public class SuperLavaItem extends BucketItem {
	public SuperLavaItem(Item.Properties properties) {
		super(RedredredModFluids.SUPER_LAVA.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}