package net.mcreator.redredred.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class RedgemSwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 323, 7f, 0, 17, TagKey.create(Registries.ITEM, ResourceLocation.parse("redredred:redgem_sword_repair_items")));

	public RedgemSwordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 6f, -2f));
	}
}