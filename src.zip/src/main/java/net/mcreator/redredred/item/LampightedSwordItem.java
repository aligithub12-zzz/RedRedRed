package net.mcreator.redredred.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class LampightedSwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1037, 11f, 0, 39, TagKey.create(Registries.ITEM, ResourceLocation.parse("redredred:lampighted_sword_repair_items")));

	public LampightedSwordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 16f, 0f));
	}
}