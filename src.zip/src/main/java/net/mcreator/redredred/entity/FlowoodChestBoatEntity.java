package net.mcreator.redredred.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.vehicle.ChestBoat;
import net.minecraft.world.entity.EntityType;

import net.mcreator.redredred.init.RedredredModItems;

public class FlowoodChestBoatEntity extends ChestBoat {
	public FlowoodChestBoatEntity(EntityType<FlowoodChestBoatEntity> type, Level world) {
		super(type, world, RedredredModItems.FLOWOOD_CHEST_BOAT);
	}
}