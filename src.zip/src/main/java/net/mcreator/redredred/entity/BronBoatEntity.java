package net.mcreator.redredred.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.entity.EntityType;

import net.mcreator.redredred.init.RedredredModItems;

public class BronBoatEntity extends Boat {
	public BronBoatEntity(EntityType<BronBoatEntity> type, Level world) {
		super(type, world, RedredredModItems.BRON_BOAT);
	}
}