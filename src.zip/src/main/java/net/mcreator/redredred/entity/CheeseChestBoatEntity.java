package net.mcreator.redredred.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.vehicle.ChestBoat;
import net.minecraft.world.entity.EntityType;

import net.mcreator.redredred.init.RedredredModItems;

public class CheeseChestBoatEntity extends ChestBoat {
	public CheeseChestBoatEntity(EntityType<CheeseChestBoatEntity> type, Level world) {
		super(type, world, RedredredModItems.CHEESE_CHEST_BOAT);
	}
}