package net.mcreator.redredred.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.entity.EntityType;

import net.mcreator.redredred.init.RedredredModItems;

public class FlowoodBoatEntity extends Boat {
	public FlowoodBoatEntity(EntityType<FlowoodBoatEntity> type, Level world) {
		super(type, world, RedredredModItems.FLOWOOD_BOAT);
	}
}