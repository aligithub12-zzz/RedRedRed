package net.mcreator.redredred.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.vehicle.ChestBoat;
import net.minecraft.world.entity.EntityType;

import net.mcreator.redredred.init.RedredredModItems;

public class BronChestBoatEntity extends ChestBoat {
	public BronChestBoatEntity(EntityType<BronChestBoatEntity> type, Level world) {
		super(type, world, RedredredModItems.BRON_CHEST_BOAT);
	}
}