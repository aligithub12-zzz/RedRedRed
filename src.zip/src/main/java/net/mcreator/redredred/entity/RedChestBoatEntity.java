package net.mcreator.redredred.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.vehicle.ChestBoat;
import net.minecraft.world.entity.EntityType;

import net.mcreator.redredred.init.RedredredModItems;

public class RedChestBoatEntity extends ChestBoat {
	public RedChestBoatEntity(EntityType<RedChestBoatEntity> type, Level world) {
		super(type, world, RedredredModItems.RED_CHEST_BOAT);
	}
}