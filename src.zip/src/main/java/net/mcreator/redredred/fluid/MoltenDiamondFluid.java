package net.mcreator.redredred.fluid;

import org.apache.logging.log4j.core.util.Source;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.redredred.init.RedredredModItems;
import net.mcreator.redredred.init.RedredredModFluids;
import net.mcreator.redredred.init.RedredredModFluidTypes;
import net.mcreator.redredred.init.RedredredModBlocks;

public abstract class MoltenDiamondFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> RedredredModFluidTypes.MOLTEN_DIAMOND_TYPE.get(), () -> RedredredModFluids.MOLTEN_DIAMOND.get(),
			() -> RedredredModFluids.FLOWING_MOLTEN_DIAMOND.get()).explosionResistance(100f).tickRate(20).bucket(() -> RedredredModItems.MOLTEN_DIAMOND_BUCKET.get()).block(() -> (LiquidBlock) RedredredModBlocks.MOLTEN_DIAMOND.get());

	private MoltenDiamondFluid() {
		super(PROPERTIES);
	}

	public static class Source extends MoltenDiamondFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends MoltenDiamondFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}