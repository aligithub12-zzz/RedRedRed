package net.mcreator.redredred.fluid;

import org.apache.logging.log4j.core.util.Source;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.redredred.init.RedredredModItems;
import net.mcreator.redredred.init.RedredredModFluids;
import net.mcreator.redredred.init.RedredredModFluidTypes;
import net.mcreator.redredred.init.RedredredModBlocks;

public abstract class NotHereFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> RedredredModFluidTypes.NOT_HERE_TYPE.get(), () -> RedredredModFluids.NOT_HERE.get(), () -> RedredredModFluids.FLOWING_NOT_HERE.get())
			.explosionResistance(100f).bucket(() -> RedredredModItems.NOT_HERE_BUCKET.get()).block(() -> (LiquidBlock) RedredredModBlocks.NOT_HERE.get());

	private NotHereFluid() {
		super(PROPERTIES);
	}

	public static class Source extends NotHereFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends NotHereFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}