package net.mcreator.redredred.fluid;

import org.apache.logging.log4j.core.util.Source;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.redredred.init.RedredredModItems;
import net.mcreator.redredred.init.RedredredModFluids;
import net.mcreator.redredred.init.RedredredModFluidTypes;
import net.mcreator.redredred.init.RedredredModBlocks;

public abstract class SuperLavaFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> RedredredModFluidTypes.SUPER_LAVA_TYPE.get(), () -> RedredredModFluids.SUPER_LAVA.get(), () -> RedredredModFluids.FLOWING_SUPER_LAVA.get())
			.explosionResistance(100f).bucket(() -> RedredredModItems.SUPER_LAVA_BUCKET.get()).block(() -> (LiquidBlock) RedredredModBlocks.SUPER_LAVA.get());

	private SuperLavaFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.FALLING_DRIPSTONE_LAVA;
	}

	public static class Source extends SuperLavaFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends SuperLavaFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}