package net.mcreator.redredred.fluid;

import org.apache.logging.log4j.core.util.Source;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.redredred.init.RedredredModParticleTypes;
import net.mcreator.redredred.init.RedredredModItems;
import net.mcreator.redredred.init.RedredredModFluids;
import net.mcreator.redredred.init.RedredredModFluidTypes;
import net.mcreator.redredred.init.RedredredModBlocks;

public abstract class ClufidFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> RedredredModFluidTypes.CLUFID_TYPE.get(), () -> RedredredModFluids.CLUFID.get(), () -> RedredredModFluids.FLOWING_CLUFID.get())
			.explosionResistance(100f).tickRate(1).slopeFindDistance(1).bucket(() -> RedredredModItems.CLUFID_BUCKET.get()).block(() -> (LiquidBlock) RedredredModBlocks.CLUFID.get());

	private ClufidFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return (SimpleParticleType) (RedredredModParticleTypes.PINK_UNKNOWNESS.get());
	}

	public static class Source extends ClufidFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends ClufidFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}