package net.mcreator.redredred.fluid;

import org.apache.logging.log4j.core.util.Source;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.redredred.init.RedredredModItems;
import net.mcreator.redredred.init.RedredredModFluids;
import net.mcreator.redredred.init.RedredredModFluidTypes;
import net.mcreator.redredred.init.RedredredModBlocks;

public abstract class StrangeLiquidFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> RedredredModFluidTypes.STRANGE_LIQUID_TYPE.get(), () -> RedredredModFluids.STRANGE_LIQUID.get(),
			() -> RedredredModFluids.FLOWING_STRANGE_LIQUID.get()).explosionResistance(100f).tickRate(1).bucket(() -> RedredredModItems.STRANGE_LIQUID_BUCKET.get()).block(() -> (LiquidBlock) RedredredModBlocks.STRANGE_LIQUID.get());

	private StrangeLiquidFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.EGG_CRACK;
	}

	public static class Source extends StrangeLiquidFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends StrangeLiquidFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}