package net.mcreator.redredred.client.toasts;

import org.jetbrains.annotations.NotNull;

import net.minecraft.world.level.entity.Visibility;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.gui.components.toasts.ToastManager;
import net.minecraft.client.gui.components.toasts.Toast;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.Font;

public class ActivRedRedRedToast implements Toast {
	private Toast.Visibility wantedVisibility = Toast.Visibility.HIDE;
	private static final ResourceLocation BACKGROUND_SPRITE = ResourceLocation.parse("redredred:textures/screens/redredredbanner");
	private static final ResourceLocation ICON_SPRITE = ResourceLocation.parse("toast:textures/screens/icon.png");
	private static final Component TITLE_TEXT = Component.translatable("toasts.redredred.activ_red_red_red.title");
	private static final Component DESCRIPTION_TEXT = Component.translatable("toasts.redredred.activ_red_red_red.description");
	private static final int DEFAULT_TIME = 10000;
	private final double displayTime;
	private final ResourceLocation icon;

	public ActivRedRedRedToast() {
		this(DEFAULT_TIME, ICON_SPRITE);
	}

	public ActivRedRedRedToast(double time) {
		this(time, ICON_SPRITE);
	}

	public ActivRedRedRedToast(double displayTime, ResourceLocation icon) {
		this.displayTime = displayTime;
		this.icon = icon;
	}

	@Override
	public @NotNull Visibility getWantedVisibility() {
		return wantedVisibility;
	}

	@Override
	public void update(@NotNull ToastManager toastManager, long lastChanged) {
		double totalMS = (double) displayTime * toastManager.getNotificationDisplayTimeMultiplier();
		this.wantedVisibility = (double) lastChanged <= totalMS ? Toast.Visibility.SHOW : Toast.Visibility.HIDE;
	}

	@Override
	public void render(GuiGraphics guiGraphics, @NotNull Font font, long l) {
		guiGraphics.blitSprite(RenderPipelines.GUI_TEXTURED, BACKGROUND_SPRITE, 0, 0, this.width(), this.height());
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, icon, 6, 6, 0, 0, 20, 20, 20, 20);
		guiGraphics.drawString(font, TITLE_TEXT, 30, 7, -16777216, true);
		guiGraphics.drawString(font, DESCRIPTION_TEXT, 30, 18, -16777216, true);
	}
}