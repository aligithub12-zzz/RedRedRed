package net.mcreator.redredred.client.gui;

import net.neoforged.neoforge.client.gui.widget.ExtendedSlider;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;

import net.mcreator.redredred.world.inventory.UselessSlidersMenu;
import net.mcreator.redredred.init.RedredredModScreens;

public class UselessSlidersScreen extends AbstractContainerScreen<UselessSlidersMenu> implements RedredredModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private EditBox tia;
	private Checkbox nothing;
	private Button button_useless_button_1;
	private Button button_useless_button_2;
	private Button button_ub3;
	private Button button_ub4;
	private ImageButton imagebutton_red_hanging_sign;
	private ExtendedSlider one;
	private ExtendedSlider two;
	private ExtendedSlider three;
	private static final ResourceLocation BACKGROUND = ResourceLocation.parse("redredred:textures/screens/useless_sliders.png");

	public UselessSlidersScreen(UselessSlidersMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		if (elementType == 0 && elementState instanceof String stringState) {
			if (name.equals("tia"))
				tia.setValue(stringState);
		}
		if (elementType == 1 && elementState instanceof Boolean logicState) {
			if (name.equals("nothing")) {
				if (nothing.selected() != logicState)
					nothing.onPress();
			}
		}
		if (elementType == 2 && elementState instanceof Number n) {
			if (name.equals("one"))
				one.setValue(n.doubleValue());
			else if (name.equals("two"))
				two.setValue(n.doubleValue());
			else if (name.equals("three"))
				three.setValue(n.doubleValue());
		}
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		tia.render(guiGraphics, mouseX, mouseY, partialTicks);
		boolean customTooltipShown = false;
		if (mouseX > leftPos + 135 && mouseX < leftPos + 159 && mouseY > topPos + 74 && mouseY < topPos + 98) {
			guiGraphics.setTooltipForNextFrame(font, Component.translatable("gui.redredred.useless_sliders.tooltip_it_does_nothing"), mouseX, mouseY);
			customTooltipShown = true;
		}
		if (!customTooltipShown)
			this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		if (tia.isFocused())
			return tia.keyPressed(key, b, c);
		return super.keyPressed(key, b, c);
	}

	@Override
	public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
		return (this.getFocused() != null && this.isDragging() && button == 0) ? this.getFocused().mouseDragged(mouseX, mouseY, button, dragX, dragY) : super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
	}

	@Override
	public void resize(Minecraft minecraft, int width, int height) {
		String tiaValue = tia.getValue();
		super.resize(minecraft, width, height);
		tia.setValue(tiaValue);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.redredred.useless_sliders.label_this_ui_does_nothing"), 23, 9, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.redredred.useless_sliders.label_o"), 135, 24, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		tia = new EditBox(this.font, this.leftPos + 10, this.topPos + 76, 118, 18, Component.translatable("gui.redredred.useless_sliders.tia"));
		tia.setMaxLength(8192);
		tia.setResponder(content -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 0, "tia", content, false);
		});
		tia.setHint(Component.translatable("gui.redredred.useless_sliders.tia"));
		this.addWidget(this.tia);
		button_useless_button_1 = Button.builder(Component.translatable("gui.redredred.useless_sliders.button_useless_button_1"), e -> {
		}).bounds(this.leftPos + 11, this.topPos + 102, 105, 20).build();
		this.addRenderableWidget(button_useless_button_1);
		button_useless_button_2 = Button.builder(Component.translatable("gui.redredred.useless_sliders.button_useless_button_2"), e -> {
		}).bounds(this.leftPos + 10, this.topPos + 130, 105, 20).build();
		this.addRenderableWidget(button_useless_button_2);
		button_ub3 = Button.builder(Component.translatable("gui.redredred.useless_sliders.button_ub3"), e -> {
		}).bounds(this.leftPos + 122, this.topPos + 102, 40, 20).build();
		this.addRenderableWidget(button_ub3);
		button_ub4 = Button.builder(Component.translatable("gui.redredred.useless_sliders.button_ub4"), e -> {
		}).bounds(this.leftPos + 123, this.topPos + 131, 40, 20).build();
		this.addRenderableWidget(button_ub4);
		imagebutton_red_hanging_sign = new ImageButton(this.leftPos + 132, this.topPos + 18, 16, 16,
				new WidgetSprites(ResourceLocation.parse("redredred:textures/screens/red_hanging_sign.png"), ResourceLocation.parse("redredred:textures/screens/red_hanging_sign.png")), e -> {
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
				guiGraphics.blit(RenderPipelines.GUI_TEXTURED, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		this.addRenderableWidget(imagebutton_red_hanging_sign);
		nothing = Checkbox.builder(Component.translatable("gui.redredred.useless_sliders.nothing"), this.font).pos(this.leftPos + 137, this.topPos + 75).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "nothing", value, false);
		}).build();
		this.addRenderableWidget(nothing);
		one = new ExtendedSlider(this.leftPos + 11, this.topPos + 46, 45, 20, Component.translatable("gui.redredred.useless_sliders.one_prefix"), Component.translatable("gui.redredred.useless_sliders.one_suffix"), 0, 20, 5, 1, 0, true) {
			@Override
			protected void applyValue() {
				if (!menuStateUpdateActive)
					menu.sendMenuStateUpdate(entity, 2, "one", this.getValue(), false);
			}
		};
		this.addRenderableWidget(one);
		if (!menuStateUpdateActive)
			menu.sendMenuStateUpdate(entity, 2, "one", one.getValue(), false);
		two = new ExtendedSlider(this.leftPos + 111, this.topPos + 46, 45, 20, Component.translatable("gui.redredred.useless_sliders.two_prefix"), Component.translatable("gui.redredred.useless_sliders.two_suffix"), 0, 20, 5, 1, 0, true) {
			@Override
			protected void applyValue() {
				if (!menuStateUpdateActive)
					menu.sendMenuStateUpdate(entity, 2, "two", this.getValue(), false);
			}
		};
		this.addRenderableWidget(two);
		if (!menuStateUpdateActive)
			menu.sendMenuStateUpdate(entity, 2, "two", two.getValue(), false);
		three = new ExtendedSlider(this.leftPos + 62, this.topPos + 46, 45, 20, Component.translatable("gui.redredred.useless_sliders.three_prefix"), Component.translatable("gui.redredred.useless_sliders.three_suffix"), 0, 20, 5, 1, 0, true) {
			@Override
			protected void applyValue() {
				if (!menuStateUpdateActive)
					menu.sendMenuStateUpdate(entity, 2, "three", this.getValue(), false);
			}
		};
		this.addRenderableWidget(three);
		if (!menuStateUpdateActive)
			menu.sendMenuStateUpdate(entity, 2, "three", three.getValue(), false);
	}
}