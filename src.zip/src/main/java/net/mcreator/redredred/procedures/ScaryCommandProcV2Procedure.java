package net.mcreator.redredred.procedures;

import net.minecraft.world.scores.criteria.ObjectiveCriteria;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.ScoreHolder;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.redredred.init.RedredredModAttributes;
import net.mcreator.redredred.RedredredMod;

public class ScaryCommandProcV2Procedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		{
			Entity _ent = entity;
			Scoreboard _sc = _ent.level().getScoreboard();
			Objective _so = _sc.getObjective("cheating_value");
			if (_so == null)
				_so = _sc.addObjective("cheating_value", ObjectiveCriteria.DUMMY, Component.literal("cheating_value"), ObjectiveCriteria.RenderType.INTEGER, true, null);
			_sc.getOrCreatePlayerScore(ScoreHolder.forNameOnly(_ent.getScoreboardName()), _so).set(1);
		}
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("...It's too late. You wanted to cheat? let's see what happens if I CHEAT..."), false);
		RedredredMod.queueServerWork(20, () -> {
			{
				Entity _ent = entity;
				if (!_ent.level().isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
							_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "kill");
				}
			}
			RedredredMod.queueServerWork(20, () -> {
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"), (-100), AttributeModifier.Operation.ADD_VALUE);
					if (!_entity.getAttribute(Attributes.LUCK).hasModifier(modifier.id())) {
						_entity.getAttribute(Attributes.LUCK).addPermanentModifier(modifier);
					}
				}
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"), (-19), AttributeModifier.Operation.ADD_VALUE);
					if (!_entity.getAttribute(Attributes.MAX_HEALTH).hasModifier(modifier.id())) {
						_entity.getAttribute(Attributes.MAX_HEALTH).addPermanentModifier(modifier);
					}
				}
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"), (-20), AttributeModifier.Operation.ADD_VALUE);
					if (!_entity.getAttribute(Attributes.ARMOR).hasModifier(modifier.id())) {
						_entity.getAttribute(Attributes.ARMOR).addPermanentModifier(modifier);
					}
				}
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"), (-40), AttributeModifier.Operation.ADD_VALUE);
					if (!_entity.getAttribute(Attributes.ATTACK_SPEED).hasModifier(modifier.id())) {
						_entity.getAttribute(Attributes.ATTACK_SPEED).addPermanentModifier(modifier);
					}
				}
				if (entity instanceof LivingEntity _entity) {
					AttributeModifier modifier = new AttributeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"), 1, AttributeModifier.Operation.ADD_VALUE);
					if (!_entity.getAttribute(RedredredModAttributes.LOSER_SCORE).hasModifier(modifier.id())) {
						_entity.getAttribute(RedredredModAttributes.LOSER_SCORE).addPermanentModifier(modifier);
					}
				}
			});
		});
	}
}