package net.mcreator.redredred.procedures;

import net.minecraft.world.scores.criteria.ObjectiveCriteria;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.ScoreHolder;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.redredred.init.RedredredModAttributes;
import net.mcreator.redredred.RedredredMod;

public class ScaryCommandProcV2undoeffectsProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("redredred:tpotintroun")), SoundSource.NEUTRAL, 1, 1);
			} else {
				_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("redredred:tpotintroun")), SoundSource.NEUTRAL, 1, 1, false);
			}
		}
		{
			Entity _ent = entity;
			Scoreboard _sc = _ent.level().getScoreboard();
			Objective _so = _sc.getObjective("cheating_value");
			if (_so == null)
				_so = _sc.addObjective("cheating_value", ObjectiveCriteria.DUMMY, Component.literal("cheating_value"), ObjectiveCriteria.RenderType.INTEGER, true, null);
			_sc.getOrCreatePlayerScore(ScoreHolder.forNameOnly(_ent.getScoreboardName()), _so).set(0);
		}
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The effects has been undone! NEVER CHEAT AGAIN..."), false);
		RedredredMod.queueServerWork(20, () -> {
			if (entity instanceof LivingEntity _entity) {
				_entity.getAttribute(Attributes.LUCK).removeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"));
			}
			if (entity instanceof LivingEntity _entity) {
				_entity.getAttribute(Attributes.MAX_HEALTH).removeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"));
			}
			if (entity instanceof LivingEntity _entity) {
				_entity.getAttribute(Attributes.ARMOR).removeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"));
			}
			if (entity instanceof LivingEntity _entity) {
				_entity.getAttribute(Attributes.ATTACK_SPEED).removeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"));
			}
			if (entity instanceof LivingEntity _entity) {
				_entity.getAttribute(RedredredModAttributes.LOSER_SCORE).removeModifier(ResourceLocation.parse("redredred:redredredanticheatv300"));
			}
		});
	}
}