package net.mcreator.redredred.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class V1012pauseinfoProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Now... why was there a LOOOONG pause in v1.0.12? Long story short, the entire workspace corrupted after a failed transfer to 26.1.2. Enjoy! "), false);
	}
}