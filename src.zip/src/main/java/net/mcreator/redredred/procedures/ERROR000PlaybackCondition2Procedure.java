package net.mcreator.redredred.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

public class ERROR000PlaybackCondition2Procedure {
	public static boolean execute(Entity entity) {
		return (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) <= 512;
	}
}