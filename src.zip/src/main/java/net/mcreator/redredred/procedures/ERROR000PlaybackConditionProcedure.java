package net.mcreator.redredred.procedures;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;

public class ERROR000PlaybackConditionProcedure {
	public static boolean execute(Entity entity) {
		return entity instanceof Mob _mobEnt0 && _mobEnt0.isAggressive();
	}
}