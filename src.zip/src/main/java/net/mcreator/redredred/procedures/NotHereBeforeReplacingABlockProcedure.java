package net.mcreator.redredred.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.redredred.RedredredMod;

public class NotHereBeforeReplacingABlockProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("redredred:tpotintroun")), SoundSource.MUSIC, 1, (float) 0.4);
			} else {
				_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("redredred:tpotintroun")), SoundSource.MUSIC, 1, (float) 0.4, false);
			}
		}
		RedredredMod.LOGGER.debug("someone killed the liquid very sad");
		assert Boolean.TRUE; //#dbg:NotHereBeforeReplacingABlock:liqu_kill_stage1
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("WHY DID YOU DO THAT NOOOOO-"), false);
		assert Boolean.TRUE; //#dbg:NotHereBeforeReplacingABlock:liqu_kill_stage2
		entity.hurt(new DamageSource(world.holderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("redredred:liquid_murder")))), 900);
		assert Boolean.TRUE; //#dbg:NotHereBeforeReplacingABlock:liqu_kill_stage3
	}
}