package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallHangingSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.redredred.init.RedredredModWoodTypes;
import net.mcreator.redredred.init.RedredredModBlocks;

public class RedWallHangingSignBlock extends WallHangingSignBlock {
	public RedWallHangingSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.RED_HANGING_SIGN_WOOD_TYPE, properties.sound(SoundType.HANGING_SIGN).strength(2f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn()
				.overrideLootTable(RedredredModBlocks.RED_HANGING_SIGN.get().getLootTable()).overrideDescription(RedredredModBlocks.RED_HANGING_SIGN.get().getDescriptionId()));
	}
}