package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.redredred.init.RedredredModWoodTypes;
import net.mcreator.redredred.init.RedredredModBlocks;

public class BronWallSignBlock extends WallSignBlock {
	public BronWallSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.BRON_SIGN_WOOD_TYPE, properties.sound(SoundType.WOOD).strength(1.3f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn()
				.overrideLootTable(RedredredModBlocks.BRON_SIGN.get().getLootTable()).overrideDescription(RedredredModBlocks.BRON_SIGN.get().getDescriptionId()));
	}
}