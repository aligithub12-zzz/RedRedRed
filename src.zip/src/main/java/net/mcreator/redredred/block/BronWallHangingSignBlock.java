package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallHangingSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.redredred.init.RedredredModWoodTypes;
import net.mcreator.redredred.init.RedredredModBlocks;

public class BronWallHangingSignBlock extends WallHangingSignBlock {
	public BronWallHangingSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.BRON_HANGING_SIGN_WOOD_TYPE, properties.sound(SoundType.HANGING_SIGN).strength(1.3f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn()
				.overrideLootTable(RedredredModBlocks.BRON_HANGING_SIGN.get().getLootTable()).overrideDescription(RedredredModBlocks.BRON_HANGING_SIGN.get().getDescriptionId()));
	}
}