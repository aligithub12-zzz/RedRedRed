package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.StandingSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.redredred.init.RedredredModWoodTypes;

public class FlowoodSignBlock extends StandingSignBlock {
	public FlowoodSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.FLOWOOD_SIGN_WOOD_TYPE, properties.sound(SoundType.WOOD).strength(3.4f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn());
	}
}