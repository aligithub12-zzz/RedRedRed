package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.CeilingHangingSignBlock;

import net.mcreator.redredred.init.RedredredModWoodTypes;

public class CheeseHangingSignBlock extends CeilingHangingSignBlock {
	public CheeseHangingSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.CHEESE_HANGING_SIGN_WOOD_TYPE, properties.sound(SoundType.HANGING_SIGN).strength(0.1f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn());
	}
}