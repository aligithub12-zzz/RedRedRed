package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.StandingSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.redredred.init.RedredredModWoodTypes;

public class CheeseSignBlock extends StandingSignBlock {
	public CheeseSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.CHEESE_SIGN_WOOD_TYPE, properties.sound(SoundType.WOOD).strength(0.1f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn());
	}
}