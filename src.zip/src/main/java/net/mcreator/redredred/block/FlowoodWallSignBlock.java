package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.redredred.init.RedredredModWoodTypes;
import net.mcreator.redredred.init.RedredredModBlocks;

public class FlowoodWallSignBlock extends WallSignBlock {
	public FlowoodWallSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.FLOWOOD_SIGN_WOOD_TYPE, properties.sound(SoundType.WOOD).strength(3.4f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn()
				.overrideLootTable(RedredredModBlocks.FLOWOOD_SIGN.get().getLootTable()).overrideDescription(RedredredModBlocks.FLOWOOD_SIGN.get().getDescriptionId()));
	}
}