package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.redredred.init.RedredredModWoodTypes;
import net.mcreator.redredred.init.RedredredModBlocks;

public class CheeseWallSignBlock extends WallSignBlock {
	public CheeseWallSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.CHEESE_SIGN_WOOD_TYPE, properties.sound(SoundType.WOOD).strength(0.1f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn()
				.overrideLootTable(RedredredModBlocks.CHEESE_SIGN.get().getLootTable()).overrideDescription(RedredredModBlocks.CHEESE_SIGN.get().getDescriptionId()));
	}
}