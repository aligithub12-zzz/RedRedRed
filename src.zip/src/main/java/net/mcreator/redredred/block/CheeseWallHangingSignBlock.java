package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallHangingSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.redredred.init.RedredredModWoodTypes;
import net.mcreator.redredred.init.RedredredModBlocks;

public class CheeseWallHangingSignBlock extends WallHangingSignBlock {
	public CheeseWallHangingSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.CHEESE_HANGING_SIGN_WOOD_TYPE, properties.sound(SoundType.HANGING_SIGN).strength(0.1f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn()
				.overrideLootTable(RedredredModBlocks.CHEESE_HANGING_SIGN.get().getLootTable()).overrideDescription(RedredredModBlocks.CHEESE_HANGING_SIGN.get().getDescriptionId()));
	}
}