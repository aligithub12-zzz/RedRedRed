package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.CeilingHangingSignBlock;

import net.mcreator.redredred.init.RedredredModWoodTypes;

public class RedHangingSignBlock extends CeilingHangingSignBlock {
	public RedHangingSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.RED_HANGING_SIGN_WOOD_TYPE, properties.sound(SoundType.HANGING_SIGN).strength(2f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn());
	}
}