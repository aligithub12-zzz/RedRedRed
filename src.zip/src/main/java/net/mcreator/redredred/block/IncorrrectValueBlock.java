package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class IncorrrectValueBlock extends Block {
	public IncorrrectValueBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GRAVEL).strength(1f, 10f).dynamicShape().offsetType(Block.OffsetType.XYZ));
	}
}