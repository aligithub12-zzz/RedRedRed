package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.redredred.init.RedredredModWoodTypes;
import net.mcreator.redredred.init.RedredredModBlocks;

public class RedWallSignBlock extends WallSignBlock {
	public RedWallSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.RED_SIGN_WOOD_TYPE, properties.sound(SoundType.WOOD).strength(2f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn()
				.overrideLootTable(RedredredModBlocks.RED_SIGN.get().getLootTable()).overrideDescription(RedredredModBlocks.RED_SIGN.get().getDescriptionId()));
	}
}