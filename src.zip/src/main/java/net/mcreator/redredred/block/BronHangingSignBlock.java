package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.CeilingHangingSignBlock;

import net.mcreator.redredred.init.RedredredModWoodTypes;

public class BronHangingSignBlock extends CeilingHangingSignBlock {
	public BronHangingSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.BRON_HANGING_SIGN_WOOD_TYPE, properties.sound(SoundType.HANGING_SIGN).strength(1.3f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn());
	}
}