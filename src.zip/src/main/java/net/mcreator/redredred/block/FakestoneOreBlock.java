package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class FakestoneOreBlock extends Block {
	public FakestoneOreBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(0.3f, 0.4754679577f).requiresCorrectToolForDrops().instrument(NoteBlockInstrument.BASEDRUM));
	}
}