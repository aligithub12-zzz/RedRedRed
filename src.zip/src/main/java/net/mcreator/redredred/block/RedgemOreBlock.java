package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class RedgemOreBlock extends Block {
	public RedgemOreBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(3.6f, 3.4710930144f).requiresCorrectToolForDrops().instrument(NoteBlockInstrument.BASEDRUM));
	}
}