package net.mcreator.redredred.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.redredred.init.RedredredModFluids;

public class StrangeLiquidBlock extends LiquidBlock {
	public StrangeLiquidBlock(BlockBehaviour.Properties properties) {
		super(RedredredModFluids.STRANGE_LIQUID.get(), properties.mapColor(MapColor.WATER).strength(100f).noCollission().noLootTable().liquid().pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable());
	}
}