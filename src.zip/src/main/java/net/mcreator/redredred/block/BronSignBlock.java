package net.mcreator.redredred.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.StandingSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.redredred.init.RedredredModWoodTypes;

public class BronSignBlock extends StandingSignBlock {
	public BronSignBlock(BlockBehaviour.Properties properties) {
		super(RedredredModWoodTypes.BRON_SIGN_WOOD_TYPE, properties.sound(SoundType.WOOD).strength(1.3f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn());
	}
}