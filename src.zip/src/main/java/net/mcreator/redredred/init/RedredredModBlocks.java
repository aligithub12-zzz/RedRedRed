/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.event.BlockEntityTypeAddBlocksEvent;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;
import net.minecraft.client.renderer.Sheets;

import net.mcreator.redredred.block.*;
import net.mcreator.redredred.RedredredMod;

import java.util.function.Function;

@EventBusSubscriber
public class RedredredModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(RedredredMod.MODID);
	public static final DeferredBlock<Block> REDGEM_ORE;
	public static final DeferredBlock<Block> REDGEM_BLOCK;
	public static final DeferredBlock<Block> RED_LOG;
	public static final DeferredBlock<Block> RED_WOOD;
	public static final DeferredBlock<Block> STRIPPED_RED_LOG;
	public static final DeferredBlock<Block> STRIPPED_RED_WOOD;
	public static final DeferredBlock<Block> RED_PLANKS;
	public static final DeferredBlock<Block> RED_LEAVES;
	public static final DeferredBlock<Block> RED_STAIRS;
	public static final DeferredBlock<Block> RED_SLAB;
	public static final DeferredBlock<Block> RED_FENCE;
	public static final DeferredBlock<Block> RED_FENCE_GATE;
	public static final DeferredBlock<Block> RED_DOOR;
	public static final DeferredBlock<Block> RED_TRAPDOOR;
	public static final DeferredBlock<Block> RED_PRESSURE_PLATE;
	public static final DeferredBlock<Block> RED_BUTTON;
	public static final DeferredBlock<Block> RED_SIGN;
	public static final DeferredBlock<Block> RED_WALL_SIGN;
	public static final DeferredBlock<Block> RED_HANGING_SIGN;
	public static final DeferredBlock<Block> RED_WALL_HANGING_SIGN;
	public static final DeferredBlock<Block> PURE_RED_BLOCK;
	public static final DeferredBlock<Block> STRANGE_LIQUID;
	public static final DeferredBlock<Block> RIMENSION_PORTAL;
	public static final DeferredBlock<Block> SUPER_LAVA;
	public static final DeferredBlock<Block> BRON_LOG;
	public static final DeferredBlock<Block> BRON_WOOD;
	public static final DeferredBlock<Block> STRIPPED_BRON_LOG;
	public static final DeferredBlock<Block> STRIPPED_BRON_WOOD;
	public static final DeferredBlock<Block> BRON_PLANKS;
	public static final DeferredBlock<Block> BRON_LEAVES;
	public static final DeferredBlock<Block> BRON_STAIRS;
	public static final DeferredBlock<Block> BRON_SLAB;
	public static final DeferredBlock<Block> BRON_FENCE;
	public static final DeferredBlock<Block> BRON_FENCE_GATE;
	public static final DeferredBlock<Block> BRON_DOOR;
	public static final DeferredBlock<Block> BRON_TRAPDOOR;
	public static final DeferredBlock<Block> BRON_PRESSURE_PLATE;
	public static final DeferredBlock<Block> BRON_BUTTON;
	public static final DeferredBlock<Block> BRON_SIGN;
	public static final DeferredBlock<Block> BRON_WALL_SIGN;
	public static final DeferredBlock<Block> BRON_HANGING_SIGN;
	public static final DeferredBlock<Block> BRON_WALL_HANGING_SIGN;
	public static final DeferredBlock<Block> TWO_X;
	public static final DeferredBlock<Block> INCORRRECT_VALUE;
	public static final DeferredBlock<Block> COLOR_BLOCK_THERA_FILLER;
	public static final DeferredBlock<Block> THERAMANION_PORTAL;
	public static final DeferredBlock<Block> LAMPIGHT;
	public static final DeferredBlock<Block> IRON_CHEST;
	public static final DeferredBlock<Block> CLUFID;
	public static final DeferredBlock<Block> HERE_SHE_IS;
	public static final DeferredBlock<Block> PLOOR;
	public static final DeferredBlock<Block> FLOWOOD_LOG;
	public static final DeferredBlock<Block> FLOWOOD_WOOD;
	public static final DeferredBlock<Block> STRIPPED_FLOWOOD_LOG;
	public static final DeferredBlock<Block> STRIPPED_FLOWOOD_WOOD;
	public static final DeferredBlock<Block> FLOWOOD_PLANKS;
	public static final DeferredBlock<Block> FLOWOOD_LEAVES;
	public static final DeferredBlock<Block> FLOWOOD_STAIRS;
	public static final DeferredBlock<Block> FLOWOOD_SLAB;
	public static final DeferredBlock<Block> FLOWOOD_FENCE;
	public static final DeferredBlock<Block> FLOWOOD_FENCE_GATE;
	public static final DeferredBlock<Block> FLOWOOD_DOOR;
	public static final DeferredBlock<Block> FLOWOOD_TRAPDOOR;
	public static final DeferredBlock<Block> FLOWOOD_PRESSURE_PLATE;
	public static final DeferredBlock<Block> FLOWOOD_BUTTON;
	public static final DeferredBlock<Block> FLOWOOD_SIGN;
	public static final DeferredBlock<Block> FLOWOOD_WALL_SIGN;
	public static final DeferredBlock<Block> FLOWOOD_HANGING_SIGN;
	public static final DeferredBlock<Block> FLOWOOD_WALL_HANGING_SIGN;
	public static final DeferredBlock<Block> BIMES;
	public static final DeferredBlock<Block> ALL_THE_BIMES_PORTAL;
	public static final DeferredBlock<Block> FLOWBLOCK;
	public static final DeferredBlock<Block> FLOWRDI_PORTAL;
	public static final DeferredBlock<Block> CRYING_NETHER_PORTAL;
	public static final DeferredBlock<Block> WIP_BLOCK;
	public static final DeferredBlock<Block> MAXDIM_PORTAL;
	public static final DeferredBlock<Block> MAXOCK;
	public static final DeferredBlock<Block> I_HATE_YOU;
	public static final DeferredBlock<Block> CRYING_STONE;
	public static final DeferredBlock<Block> CHEESE_BLOCK;
	public static final DeferredBlock<Block> CHEESE_LOG;
	public static final DeferredBlock<Block> CHEESE_WOOD;
	public static final DeferredBlock<Block> STRIPPED_CHEESE_LOG;
	public static final DeferredBlock<Block> STRIPPED_CHEESE_WOOD;
	public static final DeferredBlock<Block> CHEESE_PLANKS;
	public static final DeferredBlock<Block> CHEESE_LEAVES;
	public static final DeferredBlock<Block> CHEESE_STAIRS;
	public static final DeferredBlock<Block> CHEESE_SLAB;
	public static final DeferredBlock<Block> CHEESE_FENCE;
	public static final DeferredBlock<Block> CHEESE_FENCE_GATE;
	public static final DeferredBlock<Block> CHEESE_DOOR;
	public static final DeferredBlock<Block> CHEESE_TRAPDOOR;
	public static final DeferredBlock<Block> CHEESE_PRESSURE_PLATE;
	public static final DeferredBlock<Block> CHEESE_BUTTON;
	public static final DeferredBlock<Block> CHEESE_SIGN;
	public static final DeferredBlock<Block> CHEESE_WALL_SIGN;
	public static final DeferredBlock<Block> CHEESE_HANGING_SIGN;
	public static final DeferredBlock<Block> CHEESE_WALL_HANGING_SIGN;
	public static final DeferredBlock<Block> GRAAAAAAAAAAS;
	public static final DeferredBlock<Block> FATAL_ERROR;
	public static final DeferredBlock<Block> FAKESTONE_ORE;
	public static final DeferredBlock<Block> FAKESTONE_BLOCK;
	public static final DeferredBlock<Block> MOLTEN_DIAMOND;
	public static final DeferredBlock<Block> RICHMENSION_PORTAL;
	public static final DeferredBlock<Block> A_BLOCK_OF_BLOCK;
	public static final DeferredBlock<Block> COLDLANDS_PORTAL;
	public static final DeferredBlock<Block> NOT_HERE;
	static {
		REDGEM_ORE = register("redgem_ore", RedgemOreBlock::new);
		REDGEM_BLOCK = register("redgem_block", RedgemBlockBlock::new);
		RED_LOG = register("red_log", RedLogBlock::new);
		RED_WOOD = register("red_wood", RedWoodBlock::new);
		STRIPPED_RED_LOG = register("stripped_red_log", StrippedRedLogBlock::new);
		STRIPPED_RED_WOOD = register("stripped_red_wood", StrippedRedWoodBlock::new);
		RED_PLANKS = register("red_planks", RedPlanksBlock::new);
		RED_LEAVES = register("red_leaves", RedLeavesBlock::new);
		RED_STAIRS = register("red_stairs", RedStairsBlock::new);
		RED_SLAB = register("red_slab", RedSlabBlock::new);
		RED_FENCE = register("red_fence", RedFenceBlock::new);
		RED_FENCE_GATE = register("red_fence_gate", RedFenceGateBlock::new);
		RED_DOOR = register("red_door", RedDoorBlock::new);
		RED_TRAPDOOR = register("red_trapdoor", RedTrapdoorBlock::new);
		RED_PRESSURE_PLATE = register("red_pressure_plate", RedPressurePlateBlock::new);
		RED_BUTTON = register("red_button", RedButtonBlock::new);
		RED_SIGN = register("red_sign", RedSignBlock::new);
		RED_WALL_SIGN = register("red_wall_sign", RedWallSignBlock::new);
		RED_HANGING_SIGN = register("red_hanging_sign", RedHangingSignBlock::new);
		RED_WALL_HANGING_SIGN = register("red_wall_hanging_sign", RedWallHangingSignBlock::new);
		PURE_RED_BLOCK = register("pure_red_block", PureRedBlockBlock::new);
		STRANGE_LIQUID = register("strange_liquid", StrangeLiquidBlock::new);
		RIMENSION_PORTAL = register("rimension_portal", RimensionPortalBlock::new);
		SUPER_LAVA = register("super_lava", SuperLavaBlock::new);
		BRON_LOG = register("bron_log", BronLogBlock::new);
		BRON_WOOD = register("bron_wood", BronWoodBlock::new);
		STRIPPED_BRON_LOG = register("stripped_bron_log", StrippedBronLogBlock::new);
		STRIPPED_BRON_WOOD = register("stripped_bron_wood", StrippedBronWoodBlock::new);
		BRON_PLANKS = register("bron_planks", BronPlanksBlock::new);
		BRON_LEAVES = register("bron_leaves", BronLeavesBlock::new);
		BRON_STAIRS = register("bron_stairs", BronStairsBlock::new);
		BRON_SLAB = register("bron_slab", BronSlabBlock::new);
		BRON_FENCE = register("bron_fence", BronFenceBlock::new);
		BRON_FENCE_GATE = register("bron_fence_gate", BronFenceGateBlock::new);
		BRON_DOOR = register("bron_door", BronDoorBlock::new);
		BRON_TRAPDOOR = register("bron_trapdoor", BronTrapdoorBlock::new);
		BRON_PRESSURE_PLATE = register("bron_pressure_plate", BronPressurePlateBlock::new);
		BRON_BUTTON = register("bron_button", BronButtonBlock::new);
		BRON_SIGN = register("bron_sign", BronSignBlock::new);
		BRON_WALL_SIGN = register("bron_wall_sign", BronWallSignBlock::new);
		BRON_HANGING_SIGN = register("bron_hanging_sign", BronHangingSignBlock::new);
		BRON_WALL_HANGING_SIGN = register("bron_wall_hanging_sign", BronWallHangingSignBlock::new);
		TWO_X = register("two_x", TwoXBlock::new);
		INCORRRECT_VALUE = register("incorrrect_value", IncorrrectValueBlock::new);
		COLOR_BLOCK_THERA_FILLER = register("color_block_thera_filler", ColorBlockTheraFillerBlock::new);
		THERAMANION_PORTAL = register("theramanion_portal", TheramanionPortalBlock::new);
		LAMPIGHT = register("lampight", LampightBlock::new);
		IRON_CHEST = register("iron_chest", IronChestBlock::new);
		CLUFID = register("clufid", ClufidBlock::new);
		HERE_SHE_IS = register("here_she_is", HereSheIsBlock::new);
		PLOOR = register("ploor", PloorBlock::new);
		FLOWOOD_LOG = register("flowood_log", FlowoodLogBlock::new);
		FLOWOOD_WOOD = register("flowood_wood", FlowoodWoodBlock::new);
		STRIPPED_FLOWOOD_LOG = register("stripped_flowood_log", StrippedFlowoodLogBlock::new);
		STRIPPED_FLOWOOD_WOOD = register("stripped_flowood_wood", StrippedFlowoodWoodBlock::new);
		FLOWOOD_PLANKS = register("flowood_planks", FlowoodPlanksBlock::new);
		FLOWOOD_LEAVES = register("flowood_leaves", FlowoodLeavesBlock::new);
		FLOWOOD_STAIRS = register("flowood_stairs", FlowoodStairsBlock::new);
		FLOWOOD_SLAB = register("flowood_slab", FlowoodSlabBlock::new);
		FLOWOOD_FENCE = register("flowood_fence", FlowoodFenceBlock::new);
		FLOWOOD_FENCE_GATE = register("flowood_fence_gate", FlowoodFenceGateBlock::new);
		FLOWOOD_DOOR = register("flowood_door", FlowoodDoorBlock::new);
		FLOWOOD_TRAPDOOR = register("flowood_trapdoor", FlowoodTrapdoorBlock::new);
		FLOWOOD_PRESSURE_PLATE = register("flowood_pressure_plate", FlowoodPressurePlateBlock::new);
		FLOWOOD_BUTTON = register("flowood_button", FlowoodButtonBlock::new);
		FLOWOOD_SIGN = register("flowood_sign", FlowoodSignBlock::new);
		FLOWOOD_WALL_SIGN = register("flowood_wall_sign", FlowoodWallSignBlock::new);
		FLOWOOD_HANGING_SIGN = register("flowood_hanging_sign", FlowoodHangingSignBlock::new);
		FLOWOOD_WALL_HANGING_SIGN = register("flowood_wall_hanging_sign", FlowoodWallHangingSignBlock::new);
		BIMES = register("bimes", BimesBlock::new);
		ALL_THE_BIMES_PORTAL = register("all_the_bimes_portal", AllTheBimesPortalBlock::new);
		FLOWBLOCK = register("flowblock", FlowblockBlock::new);
		FLOWRDI_PORTAL = register("flowrdi_portal", FlowrdiPortalBlock::new);
		CRYING_NETHER_PORTAL = register("crying_nether_portal", CryingNetherPortalBlock::new);
		WIP_BLOCK = register("wip_block", WIPBlockBlock::new);
		MAXDIM_PORTAL = register("maxdim_portal", MaxdimPortalBlock::new);
		MAXOCK = register("maxock", MaxockBlock::new);
		I_HATE_YOU = register("i_hate_you", IHateYouBlock::new);
		CRYING_STONE = register("crying_stone", CryingStoneBlock::new);
		CHEESE_BLOCK = register("cheese_block", CheeseBlockBlock::new);
		CHEESE_LOG = register("cheese_log", CheeseLogBlock::new);
		CHEESE_WOOD = register("cheese_wood", CheeseWoodBlock::new);
		STRIPPED_CHEESE_LOG = register("stripped_cheese_log", StrippedCheeseLogBlock::new);
		STRIPPED_CHEESE_WOOD = register("stripped_cheese_wood", StrippedCheeseWoodBlock::new);
		CHEESE_PLANKS = register("cheese_planks", CheesePlanksBlock::new);
		CHEESE_LEAVES = register("cheese_leaves", CheeseLeavesBlock::new);
		CHEESE_STAIRS = register("cheese_stairs", CheeseStairsBlock::new);
		CHEESE_SLAB = register("cheese_slab", CheeseSlabBlock::new);
		CHEESE_FENCE = register("cheese_fence", CheeseFenceBlock::new);
		CHEESE_FENCE_GATE = register("cheese_fence_gate", CheeseFenceGateBlock::new);
		CHEESE_DOOR = register("cheese_door", CheeseDoorBlock::new);
		CHEESE_TRAPDOOR = register("cheese_trapdoor", CheeseTrapdoorBlock::new);
		CHEESE_PRESSURE_PLATE = register("cheese_pressure_plate", CheesePressurePlateBlock::new);
		CHEESE_BUTTON = register("cheese_button", CheeseButtonBlock::new);
		CHEESE_SIGN = register("cheese_sign", CheeseSignBlock::new);
		CHEESE_WALL_SIGN = register("cheese_wall_sign", CheeseWallSignBlock::new);
		CHEESE_HANGING_SIGN = register("cheese_hanging_sign", CheeseHangingSignBlock::new);
		CHEESE_WALL_HANGING_SIGN = register("cheese_wall_hanging_sign", CheeseWallHangingSignBlock::new);
		GRAAAAAAAAAAS = register("graaaaaaaaaas", GraaaaaaaaaasBlock::new);
		FATAL_ERROR = register("fatal_error", FatalErrorBlock::new);
		FAKESTONE_ORE = register("fakestone_ore", FakestoneOreBlock::new);
		FAKESTONE_BLOCK = register("fakestone_block", FakestoneBlockBlock::new);
		MOLTEN_DIAMOND = register("molten_diamond", MoltenDiamondBlock::new);
		RICHMENSION_PORTAL = register("richmension_portal", RichmensionPortalBlock::new);
		A_BLOCK_OF_BLOCK = register("a_block_of_block", ABlockOfBlockBlock::new);
		COLDLANDS_PORTAL = register("coldlands_portal", ColdlandsPortalBlock::new);
		NOT_HERE = register("not_here", NotHereBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}

	@EventBusSubscriber(Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			ColorBlockTheraFillerBlock.blockColorLoad(event);
			GraaaaaaaaaasBlock.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			Sheets.addWoodType(RedredredModWoodTypes.RED_SIGN_WOOD_TYPE);
			Sheets.addWoodType(RedredredModWoodTypes.RED_HANGING_SIGN_WOOD_TYPE);
			Sheets.addWoodType(RedredredModWoodTypes.BRON_SIGN_WOOD_TYPE);
			Sheets.addWoodType(RedredredModWoodTypes.BRON_HANGING_SIGN_WOOD_TYPE);
			Sheets.addWoodType(RedredredModWoodTypes.FLOWOOD_SIGN_WOOD_TYPE);
			Sheets.addWoodType(RedredredModWoodTypes.FLOWOOD_HANGING_SIGN_WOOD_TYPE);
			Sheets.addWoodType(RedredredModWoodTypes.CHEESE_SIGN_WOOD_TYPE);
			Sheets.addWoodType(RedredredModWoodTypes.CHEESE_HANGING_SIGN_WOOD_TYPE);
		}
	}

	@SubscribeEvent
	public static void registerSigns(BlockEntityTypeAddBlocksEvent event) {
		event.modify(BlockEntityType.SIGN, RED_SIGN.get(), RED_WALL_SIGN.get());
		event.modify(BlockEntityType.HANGING_SIGN, RED_HANGING_SIGN.get(), RED_WALL_HANGING_SIGN.get());
		event.modify(BlockEntityType.SIGN, BRON_SIGN.get(), BRON_WALL_SIGN.get());
		event.modify(BlockEntityType.HANGING_SIGN, BRON_HANGING_SIGN.get(), BRON_WALL_HANGING_SIGN.get());
		event.modify(BlockEntityType.SIGN, FLOWOOD_SIGN.get(), FLOWOOD_WALL_SIGN.get());
		event.modify(BlockEntityType.HANGING_SIGN, FLOWOOD_HANGING_SIGN.get(), FLOWOOD_WALL_HANGING_SIGN.get());
		event.modify(BlockEntityType.SIGN, CHEESE_SIGN.get(), CHEESE_WALL_SIGN.get());
		event.modify(BlockEntityType.HANGING_SIGN, CHEESE_HANGING_SIGN.get(), CHEESE_WALL_HANGING_SIGN.get());
	}
}