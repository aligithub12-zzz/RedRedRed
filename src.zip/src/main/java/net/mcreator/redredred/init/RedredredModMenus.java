/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.registries.Registries;
import net.minecraft.client.Minecraft;

import net.mcreator.redredred.world.inventory.UselessSlidersMenu;
import net.mcreator.redredred.world.inventory.UselessMenu;
import net.mcreator.redredred.world.inventory.StoreItems5Menu;
import net.mcreator.redredred.network.MenuStateUpdateMessage;
import net.mcreator.redredred.RedredredMod;

import java.util.Map;

public class RedredredModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, RedredredMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<UselessMenu>> USELESS = REGISTRY.register("useless", () -> IMenuTypeExtension.create(UselessMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<UselessSlidersMenu>> USELESS_SLIDERS = REGISTRY.register("useless_sliders", () -> IMenuTypeExtension.create(UselessSlidersMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<StoreItems5Menu>> STORE_ITEMS_5 = REGISTRY.register("store_items_5", () -> IMenuTypeExtension.create(StoreItems5Menu::new));

	public interface MenuAccessor {
		Map<String, Object> getMenuState();

		Map<Integer, Slot> getSlots();

		default void sendMenuStateUpdate(Player player, int elementType, String name, Object elementState, boolean needClientUpdate) {
			getMenuState().put(elementType + ":" + name, elementState);
			if (player instanceof ServerPlayer serverPlayer) {
				PacketDistributor.sendToPlayer(serverPlayer, new MenuStateUpdateMessage(elementType, name, elementState));
			} else if (player.level().isClientSide) {
				if (Minecraft.getInstance().screen instanceof RedredredModScreens.ScreenAccessor accessor && needClientUpdate)
					accessor.updateMenuState(elementType, name, elementState);
				ClientPacketDistributor.sendToServer(new MenuStateUpdateMessage(elementType, name, elementState));
			}
		}

		default <T> T getMenuState(int elementType, String name, T defaultValue) {
			try {
				return (T) getMenuState().getOrDefault(elementType + ":" + name, defaultValue);
			} catch (ClassCastException e) {
				return defaultValue;
			}
		}
	}
}