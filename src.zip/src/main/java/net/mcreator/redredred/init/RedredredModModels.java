/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.BoatModel;

@EventBusSubscriber(Dist.CLIENT)
public class RedredredModModels {
	public static final ModelLayerLocation RED_BOAT_LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.parse("redredred:boat/red_boat"), "main");
	public static final ModelLayerLocation RED_CHEST_BOAT_LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.parse("redredred:chest_boat/red_chest_boat"), "main");
	public static final ModelLayerLocation BRON_BOAT_LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.parse("redredred:boat/bron_boat"), "main");
	public static final ModelLayerLocation BRON_CHEST_BOAT_LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.parse("redredred:chest_boat/bron_chest_boat"), "main");
	public static final ModelLayerLocation FLOWOOD_BOAT_LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.parse("redredred:boat/flowood_boat"), "main");
	public static final ModelLayerLocation FLOWOOD_CHEST_BOAT_LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.parse("redredred:chest_boat/flowood_chest_boat"), "main");

	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(RED_BOAT_LAYER_LOCATION, BoatModel::createBoatModel);
		event.registerLayerDefinition(RED_CHEST_BOAT_LAYER_LOCATION, BoatModel::createChestBoatModel);
		event.registerLayerDefinition(BRON_BOAT_LAYER_LOCATION, BoatModel::createBoatModel);
		event.registerLayerDefinition(BRON_CHEST_BOAT_LAYER_LOCATION, BoatModel::createChestBoatModel);
		event.registerLayerDefinition(FLOWOOD_BOAT_LAYER_LOCATION, BoatModel::createBoatModel);
		event.registerLayerDefinition(FLOWOOD_CHEST_BOAT_LAYER_LOCATION, BoatModel::createChestBoatModel);
	}
}