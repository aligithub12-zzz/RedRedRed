/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.block.state.properties.BlockSetType;

public class RedredredModWoodTypes {
	public static final WoodType RED_SIGN_WOOD_TYPE = WoodType.register(new WoodType("redredred:red_sign", BlockSetType.OAK));
	public static final WoodType RED_HANGING_SIGN_WOOD_TYPE = WoodType.register(new WoodType("redredred:red_hanging_sign", BlockSetType.OAK));
	public static final WoodType BRON_SIGN_WOOD_TYPE = WoodType.register(new WoodType("redredred:bron_sign", BlockSetType.OAK));
	public static final WoodType BRON_HANGING_SIGN_WOOD_TYPE = WoodType.register(new WoodType("redredred:bron_hanging_sign", BlockSetType.OAK));
	public static final WoodType FLOWOOD_SIGN_WOOD_TYPE = WoodType.register(new WoodType("redredred:flowood_sign", BlockSetType.OAK));
	public static final WoodType FLOWOOD_HANGING_SIGN_WOOD_TYPE = WoodType.register(new WoodType("redredred:flowood_hanging_sign", BlockSetType.OAK));
}