/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.redredred.RedredredMod;

@EventBusSubscriber
public class RedredredModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RedredredMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> RED_RED_RED_BLOCKS = REGISTRY.register("red_red_red_blocks",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.redredred.red_red_red_blocks")).icon(() -> new ItemStack(RedredredModBlocks.REDGEM_BLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RedredredModBlocks.PURE_RED_BLOCK.get().asItem());
				tabData.accept(RedredredModItems.RIMENSION.get());
			}).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> INSANE_ITEMS = REGISTRY.register("insane_items",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.redredred.insane_items")).icon(() -> new ItemStack(RedredredModItems.TPOT.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RedredredModItems.STRANGE_LIQUID_BUCKET.get());
				tabData.accept(RedredredModItems.SUPER_LAVA_BUCKET.get());
				tabData.accept(RedredredModItems.TPOT.get());
				tabData.accept(RedredredModItems.BRON_ARMOR_HELMET.get());
				tabData.accept(RedredredModItems.BRON_ARMOR_CHESTPLATE.get());
				tabData.accept(RedredredModItems.BRON_ARMOR_LEGGINGS.get());
				tabData.accept(RedredredModItems.BRON_ARMOR_BOOTS.get());
				tabData.accept(RedredredModItems.CLUFID_BUCKET.get());
				tabData.accept(RedredredModItems.INSTAMINE_3000.get());
				tabData.accept(RedredredModItems.ALL_THE_BIMES.get());
				tabData.accept(RedredredModItems.FLOWRDI.get());
				tabData.accept(RedredredModItems.ABSOLUTELY_NOTHING.get());
				tabData.accept(RedredredModItems.CRYING_NETHER.get());
				tabData.accept(RedredredModItems.MAXDIM.get());
				tabData.accept(RedredredModItems.I_HATE_YOU_BUCKET.get());
				tabData.accept(RedredredModItems.BROKEN_TPOT.get());
				tabData.accept(RedredredModItems.SEVERELY_CRACKED_TPOT_MUSIC_DISC.get());
			}).withSearchBar().withTabsBefore(RED_RED_RED_BLOCKS.getId()).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> INSANE_BLOCKS = REGISTRY.register("insane_blocks",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.redredred.insane_blocks")).icon(() -> new ItemStack(RedredredModBlocks.TWO_X.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RedredredModBlocks.TWO_X.get().asItem());
				tabData.accept(RedredredModBlocks.INCORRRECT_VALUE.get().asItem());
				tabData.accept(RedredredModBlocks.COLOR_BLOCK_THERA_FILLER.get().asItem());
				tabData.accept(RedredredModBlocks.LAMPIGHT.get().asItem());
				tabData.accept(RedredredModBlocks.IRON_CHEST.get().asItem());
				tabData.accept(RedredredModBlocks.HERE_SHE_IS.get().asItem());
				tabData.accept(RedredredModBlocks.BIMES.get().asItem());
				tabData.accept(RedredredModBlocks.FLOWBLOCK.get().asItem());
				tabData.accept(RedredredModBlocks.MAXOCK.get().asItem());
				tabData.accept(RedredredModBlocks.CRYING_STONE.get().asItem());
				tabData.accept(RedredredModBlocks.CHEESE_BLOCK.get().asItem());
			}).withSearchBar().withTabsBefore(INSANE_ITEMS.getId()).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> CREATIVE_OLNY_ITEMS_OR_BLOCKS = REGISTRY.register("creative_olny_items_or_blocks",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.redredred.creative_olny_items_or_blocks")).icon(() -> new ItemStack(RedredredModBlocks.WIP_BLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RedredredModBlocks.WIP_BLOCK.get().asItem());
				tabData.accept(RedredredModBlocks.FATAL_ERROR.get().asItem());
				tabData.accept(RedredredModItems.ERROR_000_SPAWN_EGG.get());
				tabData.accept(RedredredModBlocks.A_BLOCK_OF_BLOCK.get().asItem());
			}).withTabsBefore(INSANE_BLOCKS.getId()).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(RedredredModItems.REDGEM.get());
			tabData.accept(RedredredModItems.FAKESTONE_DUST.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(RedredredModBlocks.REDGEM_ORE.get().asItem());
			tabData.accept(RedredredModBlocks.REDGEM_BLOCK.get().asItem());
			tabData.accept(RedredredModBlocks.RED_LOG.get().asItem());
			tabData.accept(RedredredModBlocks.RED_WOOD.get().asItem());
			tabData.accept(RedredredModBlocks.STRIPPED_RED_LOG.get().asItem());
			tabData.accept(RedredredModBlocks.STRIPPED_RED_WOOD.get().asItem());
			tabData.accept(RedredredModBlocks.RED_PLANKS.get().asItem());
			tabData.accept(RedredredModBlocks.RED_STAIRS.get().asItem());
			tabData.accept(RedredredModBlocks.RED_SLAB.get().asItem());
			tabData.accept(RedredredModBlocks.RED_FENCE.get().asItem());
			tabData.accept(RedredredModBlocks.RED_FENCE_GATE.get().asItem());
			tabData.accept(RedredredModBlocks.RED_DOOR.get().asItem());
			tabData.accept(RedredredModBlocks.RED_TRAPDOOR.get().asItem());
			tabData.accept(RedredredModBlocks.RED_PRESSURE_PLATE.get().asItem());
			tabData.accept(RedredredModBlocks.RED_BUTTON.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_LOG.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_WOOD.get().asItem());
			tabData.accept(RedredredModBlocks.STRIPPED_BRON_LOG.get().asItem());
			tabData.accept(RedredredModBlocks.STRIPPED_BRON_WOOD.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_PLANKS.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_STAIRS.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_SLAB.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_FENCE.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_FENCE_GATE.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_DOOR.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_TRAPDOOR.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_PRESSURE_PLATE.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_BUTTON.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_LOG.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_WOOD.get().asItem());
			tabData.accept(RedredredModBlocks.STRIPPED_FLOWOOD_LOG.get().asItem());
			tabData.accept(RedredredModBlocks.STRIPPED_FLOWOOD_WOOD.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_PLANKS.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_STAIRS.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_SLAB.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_FENCE.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_FENCE_GATE.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_DOOR.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_TRAPDOOR.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_PRESSURE_PLATE.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_BUTTON.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_LOG.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_WOOD.get().asItem());
			tabData.accept(RedredredModBlocks.STRIPPED_CHEESE_LOG.get().asItem());
			tabData.accept(RedredredModBlocks.STRIPPED_CHEESE_WOOD.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_PLANKS.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_STAIRS.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_SLAB.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_FENCE.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_FENCE_GATE.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_DOOR.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_TRAPDOOR.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_PRESSURE_PLATE.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_BUTTON.get().asItem());
			tabData.accept(RedredredModBlocks.FAKESTONE_ORE.get().asItem());
			tabData.accept(RedredredModBlocks.FAKESTONE_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(RedredredModItems.REDGEM_PICKAXE.get());
			tabData.accept(RedredredModItems.REDGEM_AXE.get());
			tabData.accept(RedredredModItems.REDGEM_SHOVEL.get());
			tabData.accept(RedredredModItems.REDGEM_HOE.get());
			tabData.accept(RedredredModItems.RED_BOAT.get());
			tabData.accept(RedredredModItems.RED_CHEST_BOAT.get());
			tabData.accept(RedredredModItems.BRON_BOAT.get());
			tabData.accept(RedredredModItems.BRON_CHEST_BOAT.get());
			tabData.accept(RedredredModItems.THERAMANION.get());
			tabData.accept(RedredredModItems.FLOWOOD_BOAT.get());
			tabData.accept(RedredredModItems.FLOWOOD_CHEST_BOAT.get());
			tabData.accept(RedredredModItems.ALL_THE_BIMES.get());
			tabData.accept(RedredredModItems.CRYING_NETHER.get());
			tabData.accept(RedredredModItems.CHEESE_BOAT.get());
			tabData.accept(RedredredModItems.CHEESE_CHEST_BOAT.get());
			tabData.accept(RedredredModItems.FAKESTONE_PICKAXE.get());
			tabData.accept(RedredredModItems.FAKESTONE_AXE.get());
			tabData.accept(RedredredModItems.FAKESTONE_SHOVEL.get());
			tabData.accept(RedredredModItems.FAKESTONE_HOE.get());
			tabData.accept(RedredredModItems.COMMAND_PICKAXE.get());
			tabData.accept(RedredredModItems.COMMAND_AXE.get());
			tabData.accept(RedredredModItems.COMMAND_SHOVEL.get());
			tabData.accept(RedredredModItems.COMMAND_HOE.get());
			tabData.accept(RedredredModItems.RICHMENSION.get());
			tabData.accept(RedredredModItems.REDSTONE_PICKAXE.get());
			tabData.accept(RedredredModItems.REDSTONE_AXE.get());
			tabData.accept(RedredredModItems.REDSTONE_SHOVEL.get());
			tabData.accept(RedredredModItems.REDSTONE_HOE.get());
			tabData.accept(RedredredModItems.REPEATING_COMMAND_PICKAXE.get());
			tabData.accept(RedredredModItems.REPEATING_COMMAND_AXE.get());
			tabData.accept(RedredredModItems.REPEATING_COMMAND_SHOVEL.get());
			tabData.accept(RedredredModItems.REPEATING_COMMAND_HOE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(RedredredModItems.REDGEM_SWORD.get());
			tabData.accept(RedredredModItems.REDGEM_ARMOR_HELMET.get());
			tabData.accept(RedredredModItems.REDGEM_ARMOR_CHESTPLATE.get());
			tabData.accept(RedredredModItems.REDGEM_ARMOR_LEGGINGS.get());
			tabData.accept(RedredredModItems.REDGEM_ARMOR_BOOTS.get());
			tabData.accept(RedredredModItems.THE_POWER_OF_TWO_ARMOR_HELMET.get());
			tabData.accept(RedredredModItems.THE_POWER_OF_TWO_ARMOR_CHESTPLATE.get());
			tabData.accept(RedredredModItems.THE_POWER_OF_TWO_ARMOR_LEGGINGS.get());
			tabData.accept(RedredredModItems.THE_POWER_OF_TWO_ARMOR_BOOTS.get());
			tabData.accept(RedredredModItems.FAKESTONE_SWORD.get());
			tabData.accept(RedredredModItems.COMMAND_SWORD.get());
			tabData.accept(RedredredModItems.COMMAND_ARMOR_HELMET.get());
			tabData.accept(RedredredModItems.COMMAND_ARMOR_CHESTPLATE.get());
			tabData.accept(RedredredModItems.COMMAND_ARMOR_LEGGINGS.get());
			tabData.accept(RedredredModItems.COMMAND_ARMOR_BOOTS.get());
			tabData.accept(RedredredModItems.REDSTONE_SWORD.get());
			tabData.accept(RedredredModItems.REPEATING_COMMAND_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(RedredredModBlocks.RED_LEAVES.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_LEAVES.get().asItem());
			tabData.accept(RedredredModBlocks.PLOOR.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_LEAVES.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_LEAVES.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(RedredredModBlocks.RED_SIGN.get().asItem());
			tabData.accept(RedredredModBlocks.RED_HANGING_SIGN.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_SIGN.get().asItem());
			tabData.accept(RedredredModBlocks.BRON_HANGING_SIGN.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_SIGN.get().asItem());
			tabData.accept(RedredredModBlocks.FLOWOOD_HANGING_SIGN.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_SIGN.get().asItem());
			tabData.accept(RedredredModBlocks.CHEESE_HANGING_SIGN.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(RedredredModItems.ALIST_12_SPAWN_EGG.get());
			tabData.accept(RedredredModItems.STRANGELY_STRANGE_SPAWN_EGG.get());
		}
	}
}