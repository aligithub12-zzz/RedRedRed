/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.redredred.fluid.SuperLavaFluid;
import net.mcreator.redredred.fluid.StrangeLiquidFluid;
import net.mcreator.redredred.fluid.MoltenDiamondFluid;
import net.mcreator.redredred.fluid.IHateYouFluid;
import net.mcreator.redredred.fluid.ClufidFluid;
import net.mcreator.redredred.RedredredMod;

public class RedredredModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, RedredredMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> STRANGE_LIQUID = REGISTRY.register("strange_liquid", () -> new StrangeLiquidFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_STRANGE_LIQUID = REGISTRY.register("flowing_strange_liquid", () -> new StrangeLiquidFluid.Flowing());
	public static final DeferredHolder<Fluid, FlowingFluid> SUPER_LAVA = REGISTRY.register("super_lava", () -> new SuperLavaFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_SUPER_LAVA = REGISTRY.register("flowing_super_lava", () -> new SuperLavaFluid.Flowing());
	public static final DeferredHolder<Fluid, FlowingFluid> CLUFID = REGISTRY.register("clufid", () -> new ClufidFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_CLUFID = REGISTRY.register("flowing_clufid", () -> new ClufidFluid.Flowing());
	public static final DeferredHolder<Fluid, FlowingFluid> I_HATE_YOU = REGISTRY.register("i_hate_you", () -> new IHateYouFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_I_HATE_YOU = REGISTRY.register("flowing_i_hate_you", () -> new IHateYouFluid.Flowing());
	public static final DeferredHolder<Fluid, FlowingFluid> MOLTEN_DIAMOND = REGISTRY.register("molten_diamond", () -> new MoltenDiamondFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_MOLTEN_DIAMOND = REGISTRY.register("flowing_molten_diamond", () -> new MoltenDiamondFluid.Flowing());

	@EventBusSubscriber(Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(STRANGE_LIQUID.get(), ChunkSectionLayer.TRANSLUCENT);
			ItemBlockRenderTypes.setRenderLayer(FLOWING_STRANGE_LIQUID.get(), ChunkSectionLayer.TRANSLUCENT);
			ItemBlockRenderTypes.setRenderLayer(SUPER_LAVA.get(), ChunkSectionLayer.TRANSLUCENT);
			ItemBlockRenderTypes.setRenderLayer(FLOWING_SUPER_LAVA.get(), ChunkSectionLayer.TRANSLUCENT);
			ItemBlockRenderTypes.setRenderLayer(CLUFID.get(), ChunkSectionLayer.TRANSLUCENT);
			ItemBlockRenderTypes.setRenderLayer(FLOWING_CLUFID.get(), ChunkSectionLayer.TRANSLUCENT);
			ItemBlockRenderTypes.setRenderLayer(I_HATE_YOU.get(), ChunkSectionLayer.TRANSLUCENT);
			ItemBlockRenderTypes.setRenderLayer(FLOWING_I_HATE_YOU.get(), ChunkSectionLayer.TRANSLUCENT);
			ItemBlockRenderTypes.setRenderLayer(MOLTEN_DIAMOND.get(), ChunkSectionLayer.TRANSLUCENT);
			ItemBlockRenderTypes.setRenderLayer(FLOWING_MOLTEN_DIAMOND.get(), ChunkSectionLayer.TRANSLUCENT);
		}
	}
}