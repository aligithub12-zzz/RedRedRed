/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.redredred.fluid.types.*;
import net.mcreator.redredred.RedredredMod;

public class RedredredModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, RedredredMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> STRANGE_LIQUID_TYPE = REGISTRY.register("strange_liquid", () -> new StrangeLiquidFluidType());
	public static final DeferredHolder<FluidType, FluidType> SUPER_LAVA_TYPE = REGISTRY.register("super_lava", () -> new SuperLavaFluidType());
	public static final DeferredHolder<FluidType, FluidType> CLUFID_TYPE = REGISTRY.register("clufid", () -> new ClufidFluidType());
	public static final DeferredHolder<FluidType, FluidType> I_HATE_YOU_TYPE = REGISTRY.register("i_hate_you", () -> new IHateYouFluidType());
	public static final DeferredHolder<FluidType, FluidType> MOLTEN_DIAMOND_TYPE = REGISTRY.register("molten_diamond", () -> new MoltenDiamondFluidType());
	public static final DeferredHolder<FluidType, FluidType> NOT_HERE_TYPE = REGISTRY.register("not_here", () -> new NotHereFluidType());
}