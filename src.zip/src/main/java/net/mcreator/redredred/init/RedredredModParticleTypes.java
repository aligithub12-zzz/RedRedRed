/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import net.mcreator.redredred.RedredredMod;

public class RedredredModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(Registries.PARTICLE_TYPE, RedredredMod.MODID);
	public static final DeferredHolder<ParticleType<?>, SimpleParticleType> PINK_UNKNOWNESS = REGISTRY.register("pink_unknowness", () -> new SimpleParticleType(false));
	public static final DeferredHolder<ParticleType<?>, SimpleParticleType> HE_IS_JUST_HERE = REGISTRY.register("he_is_just_here", () -> new SimpleParticleType(false));
	public static final DeferredHolder<ParticleType<?>, SimpleParticleType> HUH_PARTICLE = REGISTRY.register("huh_particle", () -> new SimpleParticleType(false));
}