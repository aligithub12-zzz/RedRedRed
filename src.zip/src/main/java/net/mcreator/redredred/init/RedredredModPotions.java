/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.redredred.RedredredMod;

public class RedredredModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, RedredredMod.MODID);
	public static final DeferredHolder<Potion, Potion> DIE = REGISTRY.register("die", () -> new Potion("die", new MobEffectInstance(MobEffects.SLOWNESS, 3600, 4, false, true), new MobEffectInstance(MobEffects.POISON, 3600, 4, false, true),
			new MobEffectInstance(MobEffects.NAUSEA, 3600, 1, false, true), new MobEffectInstance(MobEffects.DARKNESS, 3600, 3, false, true), new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 3600, 254, false, true)));
	public static final DeferredHolder<Potion, Potion> PURPLE_DEATH = REGISTRY.register("purple_death", () -> new Potion("purple_death", new MobEffectInstance(RedredredModMobEffects.DEATH, 3600, 0, false, true)));
	public static final DeferredHolder<Potion, Potion> PUFFBALL = REGISTRY.register("puffball",
			() -> new Potion("puffball", new MobEffectInstance(MobEffects.LEVITATION, 30, 2, false, true), new MobEffectInstance(MobEffects.SPEED, 3600, 0, false, true), new MobEffectInstance(MobEffects.GLOWING, 3600, 0, false, true)));
	public static final DeferredHolder<Potion, Potion> DUMMY_DUM_DUM = REGISTRY.register("dummy_dum_dum",
			() -> new Potion("dummy_dum_dum", new MobEffectInstance(RedredredModMobEffects.DUMMY, 3600, 0, false, true), new MobEffectInstance(MobEffects.UNLUCK, 3600, 100, false, true)));
	public static final DeferredHolder<Potion, Potion> HALFED_UP_ITEM = REGISTRY.register("halfed_up_item",
			() -> new Potion("halfed_up_item", new MobEffectInstance(RedredredModMobEffects.HALFED_UP, 3600, 0, false, true), new MobEffectInstance(MobEffects.NAUSEA, 240, 0, false, false)));
	public static final DeferredHolder<Potion, Potion> WAIT_WHAT_POTION = REGISTRY.register("wait_what_potion", () -> new Potion("wait_what_potion", new MobEffectInstance(RedredredModMobEffects.WAIT_WHAT, 3600, 0, false, true),
			new MobEffectInstance(MobEffects.BLINDNESS, 360, 0, false, true), new MobEffectInstance(MobEffects.WEAKNESS, 5700, 0, false, true)));
}