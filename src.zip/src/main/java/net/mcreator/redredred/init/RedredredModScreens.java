/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.redredred.client.gui.UselessSlidersScreen;
import net.mcreator.redredred.client.gui.UselessScreen;
import net.mcreator.redredred.client.gui.StoreItems5Screen;

@EventBusSubscriber(Dist.CLIENT)
public class RedredredModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(RedredredModMenus.USELESS.get(), UselessScreen::new);
		event.register(RedredredModMenus.USELESS_SLIDERS.get(), UselessSlidersScreen::new);
		event.register(RedredredModMenus.STORE_ITEMS_5.get(), StoreItems5Screen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}