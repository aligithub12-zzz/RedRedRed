/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.EntityAttributeModificationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.redredred.RedredredMod;

@EventBusSubscriber
public class RedredredModAttributes {
	public static final DeferredRegister<Attribute> REGISTRY = DeferredRegister.create(BuiltInRegistries.ATTRIBUTE, RedredredMod.MODID);
	public static final DeferredHolder<Attribute, Attribute> LOSER_SCORE = REGISTRY.register("loser_score", () -> new RangedAttribute("attribute.redredred.loser_score", 0, 0, 1).setSyncable(true).setSentiment(Attribute.Sentiment.NEGATIVE));

	@SubscribeEvent
	public static void addAttributes(EntityAttributeModificationEvent event) {
		event.getTypes().forEach(entity -> event.add(entity, LOSER_SCORE));
	}
}