/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.redredred.RedredredMod;

public class RedredredModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, RedredredMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> TPOTINTROUN = REGISTRY.register("tpotintroun", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("redredred", "tpotintroun")));
}