/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.redredred.client.particle.PinkUnknownessParticle;
import net.mcreator.redredred.client.particle.HuhParticleParticle;
import net.mcreator.redredred.client.particle.HeIsJustHereParticle;

@EventBusSubscriber(Dist.CLIENT)
public class RedredredModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(RedredredModParticleTypes.PINK_UNKNOWNESS.get(), PinkUnknownessParticle::provider);
		event.registerSpriteSet(RedredredModParticleTypes.HE_IS_JUST_HERE.get(), HeIsJustHereParticle::provider);
		event.registerSpriteSet(RedredredModParticleTypes.HUH_PARTICLE.get(), HuhParticleParticle::provider);
	}
}