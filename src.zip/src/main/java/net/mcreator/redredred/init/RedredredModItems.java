/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.capability.wrappers.FluidBucketWrapper;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.*;

import net.mcreator.redredred.item.*;
import net.mcreator.redredred.RedredredMod;

import java.util.function.Function;

@EventBusSubscriber
public class RedredredModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(RedredredMod.MODID);
	public static final DeferredItem<Item> REDGEM;
	public static final DeferredItem<Item> REDGEM_ORE;
	public static final DeferredItem<Item> REDGEM_BLOCK;
	public static final DeferredItem<Item> REDGEM_PICKAXE;
	public static final DeferredItem<Item> REDGEM_AXE;
	public static final DeferredItem<Item> REDGEM_SWORD;
	public static final DeferredItem<Item> REDGEM_SHOVEL;
	public static final DeferredItem<Item> REDGEM_HOE;
	public static final DeferredItem<Item> REDGEM_ARMOR_HELMET;
	public static final DeferredItem<Item> REDGEM_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> REDGEM_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> REDGEM_ARMOR_BOOTS;
	public static final DeferredItem<Item> RED_LOG;
	public static final DeferredItem<Item> RED_WOOD;
	public static final DeferredItem<Item> STRIPPED_RED_LOG;
	public static final DeferredItem<Item> STRIPPED_RED_WOOD;
	public static final DeferredItem<Item> RED_PLANKS;
	public static final DeferredItem<Item> RED_LEAVES;
	public static final DeferredItem<Item> RED_STAIRS;
	public static final DeferredItem<Item> RED_SLAB;
	public static final DeferredItem<Item> RED_FENCE;
	public static final DeferredItem<Item> RED_FENCE_GATE;
	public static final DeferredItem<Item> RED_DOOR;
	public static final DeferredItem<Item> RED_TRAPDOOR;
	public static final DeferredItem<Item> RED_PRESSURE_PLATE;
	public static final DeferredItem<Item> RED_BUTTON;
	public static final DeferredItem<Item> RED_SIGN;
	public static final DeferredItem<Item> RED_HANGING_SIGN;
	public static final DeferredItem<Item> RED_BOAT;
	public static final DeferredItem<Item> RED_CHEST_BOAT;
	public static final DeferredItem<Item> PURE_RED_BLOCK;
	public static final DeferredItem<Item> STRANGE_LIQUID_BUCKET;
	public static final DeferredItem<Item> RIMENSION;
	public static final DeferredItem<Item> SUPER_LAVA_BUCKET;
	public static final DeferredItem<Item> BRON_LOG;
	public static final DeferredItem<Item> BRON_WOOD;
	public static final DeferredItem<Item> STRIPPED_BRON_LOG;
	public static final DeferredItem<Item> STRIPPED_BRON_WOOD;
	public static final DeferredItem<Item> BRON_PLANKS;
	public static final DeferredItem<Item> BRON_LEAVES;
	public static final DeferredItem<Item> BRON_STAIRS;
	public static final DeferredItem<Item> BRON_SLAB;
	public static final DeferredItem<Item> BRON_FENCE;
	public static final DeferredItem<Item> BRON_FENCE_GATE;
	public static final DeferredItem<Item> BRON_DOOR;
	public static final DeferredItem<Item> BRON_TRAPDOOR;
	public static final DeferredItem<Item> BRON_PRESSURE_PLATE;
	public static final DeferredItem<Item> BRON_BUTTON;
	public static final DeferredItem<Item> BRON_SIGN;
	public static final DeferredItem<Item> BRON_HANGING_SIGN;
	public static final DeferredItem<Item> BRON_BOAT;
	public static final DeferredItem<Item> BRON_CHEST_BOAT;
	public static final DeferredItem<Item> TWO_X;
	public static final DeferredItem<Item> INCORRRECT_VALUE;
	public static final DeferredItem<Item> COLOR_BLOCK_THERA_FILLER;
	public static final DeferredItem<Item> ALIST_12_SPAWN_EGG;
	public static final DeferredItem<Item> THERAMANION;
	public static final DeferredItem<Item> TPOT;
	public static final DeferredItem<Item> LAMPIGHT;
	public static final DeferredItem<Item> BRON_ARMOR_HELMET;
	public static final DeferredItem<Item> BRON_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> BRON_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> BRON_ARMOR_BOOTS;
	public static final DeferredItem<Item> IRON_CHEST;
	public static final DeferredItem<Item> CLUFID_BUCKET;
	public static final DeferredItem<Item> YELGEM;
	public static final DeferredItem<Item> INSTAMINE_3000;
	public static final DeferredItem<Item> MOHAMMED_A_MOB_SPAWN_EGG;
	public static final DeferredItem<Item> HERE_SHE_IS;
	public static final DeferredItem<Item> PLOOR;
	public static final DeferredItem<Item> FLOWOOD_LOG;
	public static final DeferredItem<Item> FLOWOOD_WOOD;
	public static final DeferredItem<Item> STRIPPED_FLOWOOD_LOG;
	public static final DeferredItem<Item> STRIPPED_FLOWOOD_WOOD;
	public static final DeferredItem<Item> FLOWOOD_PLANKS;
	public static final DeferredItem<Item> FLOWOOD_LEAVES;
	public static final DeferredItem<Item> FLOWOOD_STAIRS;
	public static final DeferredItem<Item> FLOWOOD_SLAB;
	public static final DeferredItem<Item> FLOWOOD_FENCE;
	public static final DeferredItem<Item> FLOWOOD_FENCE_GATE;
	public static final DeferredItem<Item> FLOWOOD_DOOR;
	public static final DeferredItem<Item> FLOWOOD_TRAPDOOR;
	public static final DeferredItem<Item> FLOWOOD_PRESSURE_PLATE;
	public static final DeferredItem<Item> FLOWOOD_BUTTON;
	public static final DeferredItem<Item> FLOWOOD_SIGN;
	public static final DeferredItem<Item> FLOWOOD_HANGING_SIGN;
	public static final DeferredItem<Item> FLOWOOD_BOAT;
	public static final DeferredItem<Item> FLOWOOD_CHEST_BOAT;
	public static final DeferredItem<Item> BIMES;
	public static final DeferredItem<Item> ALL_THE_BIMES;
	public static final DeferredItem<Item> FLOWBLOCK;
	public static final DeferredItem<Item> FLOWRDI;
	public static final DeferredItem<Item> ABSOLUTELY_NOTHING;
	public static final DeferredItem<Item> CRYING_NETHER;
	public static final DeferredItem<Item> WIP_BLOCK;
	public static final DeferredItem<Item> MAXDIM;
	public static final DeferredItem<Item> MAXOCK;
	public static final DeferredItem<Item> I_HATE_YOU_BUCKET;
	public static final DeferredItem<Item> CRYING_STONE;
	public static final DeferredItem<Item> CHEESE_BLOCK;
	public static final DeferredItem<Item> CHEESE_LOG;
	public static final DeferredItem<Item> CHEESE_WOOD;
	public static final DeferredItem<Item> STRIPPED_CHEESE_LOG;
	public static final DeferredItem<Item> STRIPPED_CHEESE_WOOD;
	public static final DeferredItem<Item> CHEESE_PLANKS;
	public static final DeferredItem<Item> CHEESE_LEAVES;
	public static final DeferredItem<Item> CHEESE_STAIRS;
	public static final DeferredItem<Item> CHEESE_SLAB;
	public static final DeferredItem<Item> CHEESE_FENCE;
	public static final DeferredItem<Item> CHEESE_FENCE_GATE;
	public static final DeferredItem<Item> CHEESE_DOOR;
	public static final DeferredItem<Item> CHEESE_TRAPDOOR;
	public static final DeferredItem<Item> CHEESE_PRESSURE_PLATE;
	public static final DeferredItem<Item> CHEESE_BUTTON;
	public static final DeferredItem<Item> CHEESE_SIGN;
	public static final DeferredItem<Item> CHEESE_HANGING_SIGN;
	public static final DeferredItem<Item> CHEESE_BOAT;
	public static final DeferredItem<Item> CHEESE_CHEST_BOAT;
	public static final DeferredItem<Item> GRAAAAAAAAAAS;
	public static final DeferredItem<Item> FATAL_ERROR;
	public static final DeferredItem<Item> STRANGELY_STRANGE_SPAWN_EGG;
	public static final DeferredItem<Item> BROKEN_TPOT;
	public static final DeferredItem<Item> THE_POWER_OF_TWO_ARMOR_HELMET;
	public static final DeferredItem<Item> THE_POWER_OF_TWO_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> THE_POWER_OF_TWO_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> THE_POWER_OF_TWO_ARMOR_BOOTS;
	public static final DeferredItem<Item> FAKESTONE_DUST;
	public static final DeferredItem<Item> FAKESTONE_ORE;
	public static final DeferredItem<Item> FAKESTONE_BLOCK;
	public static final DeferredItem<Item> FAKESTONE_PICKAXE;
	public static final DeferredItem<Item> FAKESTONE_AXE;
	public static final DeferredItem<Item> FAKESTONE_SWORD;
	public static final DeferredItem<Item> FAKESTONE_SHOVEL;
	public static final DeferredItem<Item> FAKESTONE_HOE;
	public static final DeferredItem<Item> COMMAND_PICKAXE;
	public static final DeferredItem<Item> COMMAND_AXE;
	public static final DeferredItem<Item> COMMAND_SWORD;
	public static final DeferredItem<Item> COMMAND_SHOVEL;
	public static final DeferredItem<Item> COMMAND_HOE;
	public static final DeferredItem<Item> SEVERELY_CRACKED_TPOT_MUSIC_DISC;
	public static final DeferredItem<Item> ERROR_000_SPAWN_EGG;
	public static final DeferredItem<Item> COMMAND_ARMOR_HELMET;
	public static final DeferredItem<Item> COMMAND_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> COMMAND_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> COMMAND_ARMOR_BOOTS;
	public static final DeferredItem<Item> MOLTEN_DIAMOND_BUCKET;
	public static final DeferredItem<Item> RICHMENSION;
	public static final DeferredItem<Item> REDSTONE_PICKAXE;
	public static final DeferredItem<Item> REDSTONE_AXE;
	public static final DeferredItem<Item> REDSTONE_SWORD;
	public static final DeferredItem<Item> REDSTONE_SHOVEL;
	public static final DeferredItem<Item> REDSTONE_HOE;
	public static final DeferredItem<Item> REPEATING_COMMAND_PICKAXE;
	public static final DeferredItem<Item> REPEATING_COMMAND_AXE;
	public static final DeferredItem<Item> REPEATING_COMMAND_SWORD;
	public static final DeferredItem<Item> REPEATING_COMMAND_SHOVEL;
	public static final DeferredItem<Item> REPEATING_COMMAND_HOE;
	public static final DeferredItem<Item> A_BLOCK_OF_BLOCK;
	public static final DeferredItem<Item> COLDLANDS;
	public static final DeferredItem<Item> LAMPIGHTED_PICKAXE;
	public static final DeferredItem<Item> LAMPIGHTED_AXE;
	public static final DeferredItem<Item> LAMPIGHTED_SWORD;
	public static final DeferredItem<Item> LAMPIGHTED_SHOVEL;
	public static final DeferredItem<Item> LAMPIGHTED_HOE;
	public static final DeferredItem<Item> AAAAAAAAAAAA_AITEM;
	public static final DeferredItem<Item> NOT_HERE_BUCKET;
	static {
		REDGEM = register("redgem", RedgemItem::new);
		REDGEM_ORE = block(RedredredModBlocks.REDGEM_ORE);
		REDGEM_BLOCK = block(RedredredModBlocks.REDGEM_BLOCK);
		REDGEM_PICKAXE = register("redgem_pickaxe", RedgemPickaxeItem::new);
		REDGEM_AXE = register("redgem_axe", RedgemAxeItem::new);
		REDGEM_SWORD = register("redgem_sword", RedgemSwordItem::new);
		REDGEM_SHOVEL = register("redgem_shovel", RedgemShovelItem::new);
		REDGEM_HOE = register("redgem_hoe", RedgemHoeItem::new);
		REDGEM_ARMOR_HELMET = register("redgem_armor_helmet", RedgemArmorItem.Helmet::new);
		REDGEM_ARMOR_CHESTPLATE = register("redgem_armor_chestplate", RedgemArmorItem.Chestplate::new);
		REDGEM_ARMOR_LEGGINGS = register("redgem_armor_leggings", RedgemArmorItem.Leggings::new);
		REDGEM_ARMOR_BOOTS = register("redgem_armor_boots", RedgemArmorItem.Boots::new);
		RED_LOG = block(RedredredModBlocks.RED_LOG);
		RED_WOOD = block(RedredredModBlocks.RED_WOOD);
		STRIPPED_RED_LOG = block(RedredredModBlocks.STRIPPED_RED_LOG);
		STRIPPED_RED_WOOD = block(RedredredModBlocks.STRIPPED_RED_WOOD);
		RED_PLANKS = block(RedredredModBlocks.RED_PLANKS);
		RED_LEAVES = block(RedredredModBlocks.RED_LEAVES);
		RED_STAIRS = block(RedredredModBlocks.RED_STAIRS);
		RED_SLAB = block(RedredredModBlocks.RED_SLAB);
		RED_FENCE = block(RedredredModBlocks.RED_FENCE);
		RED_FENCE_GATE = block(RedredredModBlocks.RED_FENCE_GATE);
		RED_DOOR = doubleBlock(RedredredModBlocks.RED_DOOR);
		RED_TRAPDOOR = block(RedredredModBlocks.RED_TRAPDOOR);
		RED_PRESSURE_PLATE = block(RedredredModBlocks.RED_PRESSURE_PLATE);
		RED_BUTTON = block(RedredredModBlocks.RED_BUTTON);
		RED_SIGN = signBlock(RedredredModBlocks.RED_SIGN, RedredredModBlocks.RED_WALL_SIGN, new Item.Properties().stacksTo(16));
		RED_HANGING_SIGN = hangingSignBlock(RedredredModBlocks.RED_HANGING_SIGN, RedredredModBlocks.RED_WALL_HANGING_SIGN, new Item.Properties().stacksTo(16));
		RED_BOAT = register("red_boat", properties -> new BoatItem(RedredredModEntities.RED_BOAT.get(), properties.stacksTo(1)));
		RED_CHEST_BOAT = register("red_chest_boat", properties -> new BoatItem(RedredredModEntities.RED_CHEST_BOAT.get(), properties.stacksTo(1)));
		PURE_RED_BLOCK = block(RedredredModBlocks.PURE_RED_BLOCK);
		STRANGE_LIQUID_BUCKET = register("strange_liquid_bucket", StrangeLiquidItem::new);
		RIMENSION = register("rimension", RimensionItem::new);
		SUPER_LAVA_BUCKET = register("super_lava_bucket", SuperLavaItem::new);
		BRON_LOG = block(RedredredModBlocks.BRON_LOG);
		BRON_WOOD = block(RedredredModBlocks.BRON_WOOD);
		STRIPPED_BRON_LOG = block(RedredredModBlocks.STRIPPED_BRON_LOG);
		STRIPPED_BRON_WOOD = block(RedredredModBlocks.STRIPPED_BRON_WOOD);
		BRON_PLANKS = block(RedredredModBlocks.BRON_PLANKS);
		BRON_LEAVES = block(RedredredModBlocks.BRON_LEAVES);
		BRON_STAIRS = block(RedredredModBlocks.BRON_STAIRS);
		BRON_SLAB = block(RedredredModBlocks.BRON_SLAB);
		BRON_FENCE = block(RedredredModBlocks.BRON_FENCE);
		BRON_FENCE_GATE = block(RedredredModBlocks.BRON_FENCE_GATE);
		BRON_DOOR = doubleBlock(RedredredModBlocks.BRON_DOOR);
		BRON_TRAPDOOR = block(RedredredModBlocks.BRON_TRAPDOOR);
		BRON_PRESSURE_PLATE = block(RedredredModBlocks.BRON_PRESSURE_PLATE);
		BRON_BUTTON = block(RedredredModBlocks.BRON_BUTTON);
		BRON_SIGN = signBlock(RedredredModBlocks.BRON_SIGN, RedredredModBlocks.BRON_WALL_SIGN, new Item.Properties().stacksTo(16));
		BRON_HANGING_SIGN = hangingSignBlock(RedredredModBlocks.BRON_HANGING_SIGN, RedredredModBlocks.BRON_WALL_HANGING_SIGN, new Item.Properties().stacksTo(16));
		BRON_BOAT = register("bron_boat", properties -> new BoatItem(RedredredModEntities.BRON_BOAT.get(), properties.stacksTo(1)));
		BRON_CHEST_BOAT = register("bron_chest_boat", properties -> new BoatItem(RedredredModEntities.BRON_CHEST_BOAT.get(), properties.stacksTo(1)));
		TWO_X = block(RedredredModBlocks.TWO_X);
		INCORRRECT_VALUE = block(RedredredModBlocks.INCORRRECT_VALUE);
		COLOR_BLOCK_THERA_FILLER = block(RedredredModBlocks.COLOR_BLOCK_THERA_FILLER);
		ALIST_12_SPAWN_EGG = register("alist_12_spawn_egg", properties -> new SpawnEggItem(RedredredModEntities.ALIST_12.get(), properties));
		THERAMANION = register("theramanion", TheramanionItem::new);
		TPOT = register("tpot", TPOTItem::new);
		LAMPIGHT = block(RedredredModBlocks.LAMPIGHT);
		BRON_ARMOR_HELMET = register("bron_armor_helmet", BronArmorItem.Helmet::new);
		BRON_ARMOR_CHESTPLATE = register("bron_armor_chestplate", BronArmorItem.Chestplate::new);
		BRON_ARMOR_LEGGINGS = register("bron_armor_leggings", BronArmorItem.Leggings::new);
		BRON_ARMOR_BOOTS = register("bron_armor_boots", BronArmorItem.Boots::new);
		IRON_CHEST = block(RedredredModBlocks.IRON_CHEST);
		CLUFID_BUCKET = register("clufid_bucket", ClufidItem::new);
		YELGEM = register("yelgem", YelgemItem::new);
		INSTAMINE_3000 = register("instamine_3000", Instamine3000Item::new);
		MOHAMMED_A_MOB_SPAWN_EGG = register("mohammed_a_mob_spawn_egg", properties -> new SpawnEggItem(RedredredModEntities.MOHAMMED_A_MOB.get(), properties));
		HERE_SHE_IS = block(RedredredModBlocks.HERE_SHE_IS);
		PLOOR = block(RedredredModBlocks.PLOOR);
		FLOWOOD_LOG = block(RedredredModBlocks.FLOWOOD_LOG);
		FLOWOOD_WOOD = block(RedredredModBlocks.FLOWOOD_WOOD);
		STRIPPED_FLOWOOD_LOG = block(RedredredModBlocks.STRIPPED_FLOWOOD_LOG);
		STRIPPED_FLOWOOD_WOOD = block(RedredredModBlocks.STRIPPED_FLOWOOD_WOOD);
		FLOWOOD_PLANKS = block(RedredredModBlocks.FLOWOOD_PLANKS);
		FLOWOOD_LEAVES = block(RedredredModBlocks.FLOWOOD_LEAVES);
		FLOWOOD_STAIRS = block(RedredredModBlocks.FLOWOOD_STAIRS);
		FLOWOOD_SLAB = block(RedredredModBlocks.FLOWOOD_SLAB);
		FLOWOOD_FENCE = block(RedredredModBlocks.FLOWOOD_FENCE);
		FLOWOOD_FENCE_GATE = block(RedredredModBlocks.FLOWOOD_FENCE_GATE);
		FLOWOOD_DOOR = doubleBlock(RedredredModBlocks.FLOWOOD_DOOR);
		FLOWOOD_TRAPDOOR = block(RedredredModBlocks.FLOWOOD_TRAPDOOR);
		FLOWOOD_PRESSURE_PLATE = block(RedredredModBlocks.FLOWOOD_PRESSURE_PLATE);
		FLOWOOD_BUTTON = block(RedredredModBlocks.FLOWOOD_BUTTON);
		FLOWOOD_SIGN = signBlock(RedredredModBlocks.FLOWOOD_SIGN, RedredredModBlocks.FLOWOOD_WALL_SIGN, new Item.Properties().stacksTo(16));
		FLOWOOD_HANGING_SIGN = hangingSignBlock(RedredredModBlocks.FLOWOOD_HANGING_SIGN, RedredredModBlocks.FLOWOOD_WALL_HANGING_SIGN, new Item.Properties().stacksTo(16));
		FLOWOOD_BOAT = register("flowood_boat", properties -> new BoatItem(RedredredModEntities.FLOWOOD_BOAT.get(), properties.stacksTo(1)));
		FLOWOOD_CHEST_BOAT = register("flowood_chest_boat", properties -> new BoatItem(RedredredModEntities.FLOWOOD_CHEST_BOAT.get(), properties.stacksTo(1)));
		BIMES = block(RedredredModBlocks.BIMES);
		ALL_THE_BIMES = register("all_the_bimes", AllTheBimesItem::new);
		FLOWBLOCK = block(RedredredModBlocks.FLOWBLOCK);
		FLOWRDI = register("flowrdi", FlowrdiItem::new);
		ABSOLUTELY_NOTHING = register("absolutely_nothing", AbsolutelyNothingItem::new);
		CRYING_NETHER = register("crying_nether", CryingNetherItem::new);
		WIP_BLOCK = block(RedredredModBlocks.WIP_BLOCK, new Item.Properties().stacksTo(99).rarity(Rarity.EPIC).fireResistant());
		MAXDIM = register("maxdim", MaxdimItem::new);
		MAXOCK = block(RedredredModBlocks.MAXOCK);
		I_HATE_YOU_BUCKET = register("i_hate_you_bucket", IHateYouItem::new);
		CRYING_STONE = block(RedredredModBlocks.CRYING_STONE);
		CHEESE_BLOCK = block(RedredredModBlocks.CHEESE_BLOCK);
		CHEESE_LOG = block(RedredredModBlocks.CHEESE_LOG);
		CHEESE_WOOD = block(RedredredModBlocks.CHEESE_WOOD);
		STRIPPED_CHEESE_LOG = block(RedredredModBlocks.STRIPPED_CHEESE_LOG);
		STRIPPED_CHEESE_WOOD = block(RedredredModBlocks.STRIPPED_CHEESE_WOOD);
		CHEESE_PLANKS = block(RedredredModBlocks.CHEESE_PLANKS);
		CHEESE_LEAVES = block(RedredredModBlocks.CHEESE_LEAVES);
		CHEESE_STAIRS = block(RedredredModBlocks.CHEESE_STAIRS);
		CHEESE_SLAB = block(RedredredModBlocks.CHEESE_SLAB);
		CHEESE_FENCE = block(RedredredModBlocks.CHEESE_FENCE);
		CHEESE_FENCE_GATE = block(RedredredModBlocks.CHEESE_FENCE_GATE);
		CHEESE_DOOR = doubleBlock(RedredredModBlocks.CHEESE_DOOR);
		CHEESE_TRAPDOOR = block(RedredredModBlocks.CHEESE_TRAPDOOR);
		CHEESE_PRESSURE_PLATE = block(RedredredModBlocks.CHEESE_PRESSURE_PLATE);
		CHEESE_BUTTON = block(RedredredModBlocks.CHEESE_BUTTON);
		CHEESE_SIGN = signBlock(RedredredModBlocks.CHEESE_SIGN, RedredredModBlocks.CHEESE_WALL_SIGN, new Item.Properties().stacksTo(16));
		CHEESE_HANGING_SIGN = hangingSignBlock(RedredredModBlocks.CHEESE_HANGING_SIGN, RedredredModBlocks.CHEESE_WALL_HANGING_SIGN, new Item.Properties().stacksTo(16));
		CHEESE_BOAT = register("cheese_boat", properties -> new BoatItem(RedredredModEntities.CHEESE_BOAT.get(), properties.stacksTo(1)));
		CHEESE_CHEST_BOAT = register("cheese_chest_boat", properties -> new BoatItem(RedredredModEntities.CHEESE_CHEST_BOAT.get(), properties.stacksTo(1)));
		GRAAAAAAAAAAS = block(RedredredModBlocks.GRAAAAAAAAAAS, new Item.Properties().stacksTo(65));
		FATAL_ERROR = block(RedredredModBlocks.FATAL_ERROR, new Item.Properties().rarity(Rarity.EPIC));
		STRANGELY_STRANGE_SPAWN_EGG = register("strangely_strange_spawn_egg", properties -> new SpawnEggItem(RedredredModEntities.STRANGELY_STRANGE.get(), properties));
		BROKEN_TPOT = register("broken_tpot", BrokenTPOTItem::new);
		THE_POWER_OF_TWO_ARMOR_HELMET = register("the_power_of_two_armor_helmet", ThePowerOfTwoArmorItem.Helmet::new);
		THE_POWER_OF_TWO_ARMOR_CHESTPLATE = register("the_power_of_two_armor_chestplate", ThePowerOfTwoArmorItem.Chestplate::new);
		THE_POWER_OF_TWO_ARMOR_LEGGINGS = register("the_power_of_two_armor_leggings", ThePowerOfTwoArmorItem.Leggings::new);
		THE_POWER_OF_TWO_ARMOR_BOOTS = register("the_power_of_two_armor_boots", ThePowerOfTwoArmorItem.Boots::new);
		FAKESTONE_DUST = register("fakestone_dust", FakestoneDustItem::new);
		FAKESTONE_ORE = block(RedredredModBlocks.FAKESTONE_ORE);
		FAKESTONE_BLOCK = block(RedredredModBlocks.FAKESTONE_BLOCK);
		FAKESTONE_PICKAXE = register("fakestone_pickaxe", FakestonePickaxeItem::new);
		FAKESTONE_AXE = register("fakestone_axe", FakestoneAxeItem::new);
		FAKESTONE_SWORD = register("fakestone_sword", FakestoneSwordItem::new);
		FAKESTONE_SHOVEL = register("fakestone_shovel", FakestoneShovelItem::new);
		FAKESTONE_HOE = register("fakestone_hoe", FakestoneHoeItem::new);
		COMMAND_PICKAXE = register("command_pickaxe", CommandPickaxeItem::new);
		COMMAND_AXE = register("command_axe", CommandAxeItem::new);
		COMMAND_SWORD = register("command_sword", CommandSwordItem::new);
		COMMAND_SHOVEL = register("command_shovel", CommandShovelItem::new);
		COMMAND_HOE = register("command_hoe", CommandHoeItem::new);
		SEVERELY_CRACKED_TPOT_MUSIC_DISC = register("severely_cracked_tpot_music_disc", SeverelyCrackedTPOTMusicDiscItem::new);
		ERROR_000_SPAWN_EGG = register("error_000_spawn_egg", properties -> new SpawnEggItem(RedredredModEntities.ERROR_000.get(), properties));
		COMMAND_ARMOR_HELMET = register("command_armor_helmet", CommandArmorItem.Helmet::new);
		COMMAND_ARMOR_CHESTPLATE = register("command_armor_chestplate", CommandArmorItem.Chestplate::new);
		COMMAND_ARMOR_LEGGINGS = register("command_armor_leggings", CommandArmorItem.Leggings::new);
		COMMAND_ARMOR_BOOTS = register("command_armor_boots", CommandArmorItem.Boots::new);
		MOLTEN_DIAMOND_BUCKET = register("molten_diamond_bucket", MoltenDiamondItem::new);
		RICHMENSION = register("richmension", RichmensionItem::new);
		REDSTONE_PICKAXE = register("redstone_pickaxe", RedstonePickaxeItem::new);
		REDSTONE_AXE = register("redstone_axe", RedstoneAxeItem::new);
		REDSTONE_SWORD = register("redstone_sword", RedstoneSwordItem::new);
		REDSTONE_SHOVEL = register("redstone_shovel", RedstoneShovelItem::new);
		REDSTONE_HOE = register("redstone_hoe", RedstoneHoeItem::new);
		REPEATING_COMMAND_PICKAXE = register("repeating_command_pickaxe", RepeatingCommandPickaxeItem::new);
		REPEATING_COMMAND_AXE = register("repeating_command_axe", RepeatingCommandAxeItem::new);
		REPEATING_COMMAND_SWORD = register("repeating_command_sword", RepeatingCommandSwordItem::new);
		REPEATING_COMMAND_SHOVEL = register("repeating_command_shovel", RepeatingCommandShovelItem::new);
		REPEATING_COMMAND_HOE = register("repeating_command_hoe", RepeatingCommandHoeItem::new);
		A_BLOCK_OF_BLOCK = block(RedredredModBlocks.A_BLOCK_OF_BLOCK);
		COLDLANDS = register("coldlands", ColdlandsItem::new);
		LAMPIGHTED_PICKAXE = register("lampighted_pickaxe", LampightedPickaxeItem::new);
		LAMPIGHTED_AXE = register("lampighted_axe", LampightedAxeItem::new);
		LAMPIGHTED_SWORD = register("lampighted_sword", LampightedSwordItem::new);
		LAMPIGHTED_SHOVEL = register("lampighted_shovel", LampightedShovelItem::new);
		LAMPIGHTED_HOE = register("lampighted_hoe", LampightedHoeItem::new);
		AAAAAAAAAAAA_AITEM = register("aaaaaaaaaaaa_aitem", AAAAAAAAAAAAAitemItem::new);
		NOT_HERE_BUCKET = register("not_here_bucket", NotHereItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}

	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block) {
		return doubleBlock(block, new Item.Properties());
	}

	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new DoubleHighBlockItem(block.get(), prop), properties);
	}

	private static DeferredItem<Item> signBlock(DeferredHolder<Block, Block> block, DeferredHolder<Block, Block> wallBlock) {
		return signBlock(block, wallBlock, new Item.Properties());
	}

	private static DeferredItem<Item> signBlock(DeferredHolder<Block, Block> block, DeferredHolder<Block, Block> wallBlock, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new SignItem(block.get(), wallBlock.get(), prop), properties);
	}

	private static DeferredItem<Item> hangingSignBlock(DeferredHolder<Block, Block> block, DeferredHolder<Block, Block> wallBlock) {
		return hangingSignBlock(block, wallBlock, new Item.Properties());
	}

	private static DeferredItem<Item> hangingSignBlock(DeferredHolder<Block, Block> block, DeferredHolder<Block, Block> wallBlock, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new HangingSignItem(block.get(), wallBlock.get(), prop), properties);
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), STRANGE_LIQUID_BUCKET.get());
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), SUPER_LAVA_BUCKET.get());
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), CLUFID_BUCKET.get());
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), I_HATE_YOU_BUCKET.get());
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), MOLTEN_DIAMOND_BUCKET.get());
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), NOT_HERE_BUCKET.get());
	}
}