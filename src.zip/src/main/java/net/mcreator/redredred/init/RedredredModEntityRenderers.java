/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.BoatRenderer;

import net.mcreator.redredred.client.renderer.StrangelyStrangeRenderer;
import net.mcreator.redredred.client.renderer.MohammedAMobRenderer;
import net.mcreator.redredred.client.renderer.ERROR000Renderer;
import net.mcreator.redredred.client.renderer.Alist12Renderer;

@EventBusSubscriber(Dist.CLIENT)
public class RedredredModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(RedredredModEntities.RED_BOAT.get(), context -> new BoatRenderer(context, RedredredModModels.RED_BOAT_LAYER_LOCATION));
		event.registerEntityRenderer(RedredredModEntities.RED_CHEST_BOAT.get(), context -> new BoatRenderer(context, RedredredModModels.RED_CHEST_BOAT_LAYER_LOCATION));
		event.registerEntityRenderer(RedredredModEntities.BRON_BOAT.get(), context -> new BoatRenderer(context, RedredredModModels.BRON_BOAT_LAYER_LOCATION));
		event.registerEntityRenderer(RedredredModEntities.BRON_CHEST_BOAT.get(), context -> new BoatRenderer(context, RedredredModModels.BRON_CHEST_BOAT_LAYER_LOCATION));
		event.registerEntityRenderer(RedredredModEntities.ALIST_12.get(), Alist12Renderer::new);
		event.registerEntityRenderer(RedredredModEntities.MOHAMMED_A_MOB.get(), MohammedAMobRenderer::new);
		event.registerEntityRenderer(RedredredModEntities.FLOWOOD_BOAT.get(), context -> new BoatRenderer(context, RedredredModModels.FLOWOOD_BOAT_LAYER_LOCATION));
		event.registerEntityRenderer(RedredredModEntities.FLOWOOD_CHEST_BOAT.get(), context -> new BoatRenderer(context, RedredredModModels.FLOWOOD_CHEST_BOAT_LAYER_LOCATION));
		event.registerEntityRenderer(RedredredModEntities.CHEESE_BOAT.get(), context -> new BoatRenderer(context, RedredredModModels.CHEESE_BOAT_LAYER_LOCATION));
		event.registerEntityRenderer(RedredredModEntities.CHEESE_CHEST_BOAT.get(), context -> new BoatRenderer(context, RedredredModModels.CHEESE_CHEST_BOAT_LAYER_LOCATION));
		event.registerEntityRenderer(RedredredModEntities.STRANGELY_STRANGE.get(), StrangelyStrangeRenderer::new);
		event.registerEntityRenderer(RedredredModEntities.ERROR_000.get(), ERROR000Renderer::new);
	}
}