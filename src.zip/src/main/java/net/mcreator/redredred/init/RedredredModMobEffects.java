/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.redredred.potion.WaitWhatMobEffect;
import net.mcreator.redredred.potion.HalfedUpMobEffect;
import net.mcreator.redredred.potion.DummyMobEffect;
import net.mcreator.redredred.potion.DeathMobEffect;
import net.mcreator.redredred.RedredredMod;

public class RedredredModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, RedredredMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> DEATH = REGISTRY.register("death", () -> new DeathMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> DUMMY = REGISTRY.register("dummy", () -> new DummyMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> HALFED_UP = REGISTRY.register("halfed_up", () -> new HalfedUpMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> WAIT_WHAT = REGISTRY.register("wait_what", () -> new WaitWhatMobEffect());
}