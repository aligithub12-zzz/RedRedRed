/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.GameRules;

@EventBusSubscriber
public class RedredredModGameRules {
	public static GameRules.Key<GameRules.BooleanValue> NO_DEATH;
	public static GameRules.Key<GameRules.BooleanValue> INSTANT_DEATH;
	public static GameRules.Key<GameRules.BooleanValue> WIDE_OPEN_POCKETS;
	public static GameRules.Key<GameRules.BooleanValue> DO_NOT_ACTIVATE_ME;

	@SubscribeEvent
	public static void registerGameRules(FMLCommonSetupEvent event) {
		NO_DEATH = GameRules.register("noDeath", GameRules.Category.PLAYER, GameRules.BooleanValue.create(false));
		INSTANT_DEATH = GameRules.register("instantDeath", GameRules.Category.PLAYER, GameRules.BooleanValue.create(false));
		WIDE_OPEN_POCKETS = GameRules.register("wideOpenPockets", GameRules.Category.PLAYER, GameRules.BooleanValue.create(false));
		DO_NOT_ACTIVATE_ME = GameRules.register("doNotActivateMe", GameRules.Category.PLAYER, GameRules.BooleanValue.create(false));
	}
}