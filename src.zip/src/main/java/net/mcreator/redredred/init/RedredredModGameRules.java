/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.GameRules;

@EventBusSubscriber
public class RedredredModGameRules {
	public static GameRules.Key<GameRules.BooleanValue> NO_DEATH;

	@SubscribeEvent
	public static void registerGameRules(FMLCommonSetupEvent event) {
		NO_DEATH = GameRules.register("noDeath", GameRules.Category.PLAYER, GameRules.BooleanValue.create(false));
	}
}