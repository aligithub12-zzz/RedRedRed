/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.core.dispenser.BoatDispenseItemBehavior;

@EventBusSubscriber
public class RedredredModDispenseBehaviors {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			DispenserBlock.registerBehavior(RedredredModItems.RED_BOAT.get(), new BoatDispenseItemBehavior(RedredredModEntities.RED_BOAT.get()));
			DispenserBlock.registerBehavior(RedredredModItems.RED_CHEST_BOAT.get(), new BoatDispenseItemBehavior(RedredredModEntities.RED_CHEST_BOAT.get()));
			DispenserBlock.registerBehavior(RedredredModItems.BRON_BOAT.get(), new BoatDispenseItemBehavior(RedredredModEntities.BRON_BOAT.get()));
			DispenserBlock.registerBehavior(RedredredModItems.BRON_CHEST_BOAT.get(), new BoatDispenseItemBehavior(RedredredModEntities.BRON_CHEST_BOAT.get()));
			DispenserBlock.registerBehavior(RedredredModItems.FLOWOOD_BOAT.get(), new BoatDispenseItemBehavior(RedredredModEntities.FLOWOOD_BOAT.get()));
			DispenserBlock.registerBehavior(RedredredModItems.FLOWOOD_CHEST_BOAT.get(), new BoatDispenseItemBehavior(RedredredModEntities.FLOWOOD_CHEST_BOAT.get()));
			DispenserBlock.registerBehavior(RedredredModItems.CHEESE_BOAT.get(), new BoatDispenseItemBehavior(RedredredModEntities.CHEESE_BOAT.get()));
			DispenserBlock.registerBehavior(RedredredModItems.CHEESE_CHEST_BOAT.get(), new BoatDispenseItemBehavior(RedredredModEntities.CHEESE_CHEST_BOAT.get()));
		});
	}
}