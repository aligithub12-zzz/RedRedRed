/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.redredred.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.redredred.entity.*;
import net.mcreator.redredred.RedredredMod;

@EventBusSubscriber
public class RedredredModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, RedredredMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<RedBoatEntity>> RED_BOAT = register("red_boat",
			EntityType.Builder.<RedBoatEntity>of(RedBoatEntity::new, MobCategory.MISC).noLootTable().sized(1.375F, 0.5625F).eyeHeight(0.5625F).clientTrackingRange(10));
	public static final DeferredHolder<EntityType<?>, EntityType<RedChestBoatEntity>> RED_CHEST_BOAT = register("red_chest_boat",
			EntityType.Builder.<RedChestBoatEntity>of(RedChestBoatEntity::new, MobCategory.MISC).noLootTable().sized(1.375F, 0.5625F).eyeHeight(0.5625F).clientTrackingRange(10));
	public static final DeferredHolder<EntityType<?>, EntityType<BronBoatEntity>> BRON_BOAT = register("bron_boat",
			EntityType.Builder.<BronBoatEntity>of(BronBoatEntity::new, MobCategory.MISC).noLootTable().sized(1.375F, 0.5625F).eyeHeight(0.5625F).clientTrackingRange(10));
	public static final DeferredHolder<EntityType<?>, EntityType<BronChestBoatEntity>> BRON_CHEST_BOAT = register("bron_chest_boat",
			EntityType.Builder.<BronChestBoatEntity>of(BronChestBoatEntity::new, MobCategory.MISC).noLootTable().sized(1.375F, 0.5625F).eyeHeight(0.5625F).clientTrackingRange(10));
	public static final DeferredHolder<EntityType<?>, EntityType<Alist12Entity>> ALIST_12 = register("alist_12",
			EntityType.Builder.<Alist12Entity>of(Alist12Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<MohammedAMobEntity>> MOHAMMED_A_MOB = register("mohammed_a_mob",
			EntityType.Builder.<MohammedAMobEntity>of(MohammedAMobEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<FlowoodBoatEntity>> FLOWOOD_BOAT = register("flowood_boat",
			EntityType.Builder.<FlowoodBoatEntity>of(FlowoodBoatEntity::new, MobCategory.MISC).noLootTable().sized(1.375F, 0.5625F).eyeHeight(0.5625F).clientTrackingRange(10));
	public static final DeferredHolder<EntityType<?>, EntityType<FlowoodChestBoatEntity>> FLOWOOD_CHEST_BOAT = register("flowood_chest_boat",
			EntityType.Builder.<FlowoodChestBoatEntity>of(FlowoodChestBoatEntity::new, MobCategory.MISC).noLootTable().sized(1.375F, 0.5625F).eyeHeight(0.5625F).clientTrackingRange(10));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(RedredredMod.MODID, registryname))));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		Alist12Entity.init(event);
		MohammedAMobEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(ALIST_12.get(), Alist12Entity.createAttributes().build());
		event.put(MOHAMMED_A_MOB.get(), MohammedAMobEntity.createAttributes().build());
	}
}